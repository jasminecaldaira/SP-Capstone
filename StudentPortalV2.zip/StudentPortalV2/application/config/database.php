<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$active_group = 'default';
$query_builder = TRUE;

if(ENVIRONMENT == 'production')
{
  $db['default']['hostname'] = 'localhost';
  $db['default']['username'] = 'root';
  $db['default']['password'] = '';
  $db['default']['dbdriver'] = 'mysqli';
  $db['default']['database'] = 'cvsunaic_cvsudatabase123qwe';
}
else
{
  $db['default']['hostname'] = 'localhost';
  $db['default']['username'] = 'root';
  $db['default']['password'] = '';
  $db['default']['dbdriver'] = 'mysqli';
  $db['default']['database'] = 'cvsunaic_cvsudatabase123qwe'; 
}
