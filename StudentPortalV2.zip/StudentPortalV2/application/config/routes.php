<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'users';
$route['home'] = '/users/home';
$route['admin'] = '/users/admin';
$route['handbook'] = '/users/handbook';
$route['admin-reset-password'] = '/users/adminResetPassword';
$route['update-adminNumber'] = '/users/updatePhoneAdmin';
$route['update-phoneAdmin'] = '/users/updateNumber';
$route['update-emailAdmin'] = '/users/updateEmailAdmin';
$route['update-admin-email'] = '/users/updateAdminEmail';
$route['user-management'] = '/users/userManagement';
$route['add-admin'] = '/users/addAdmin';
$route['create-admin'] = '/users/createAdmin';
$route['admin-home'] = '/users/adminHome';
$route['admin-dashboard'] = '/users/adminDashboard';
$route['reset-password'] = '/users/resetPassword';
$route['update'] = '/users/update';
$route['password-profile'] = '/users/passwordProfile';
$route['updatemyacc'] = '/users/updatemyacc';
$route['updatemyyacc'] = '/users/updatemyyacc';
$route['adminList'] = '/users/adminList';
$route['studData'] = '/users/studData';

$route['updateSem'] = '';

$route['change-password'] = '/users/changePassword';
$route['change-pass'] = '/users/changePass';


$route['class-schedule'] = '/users/schedule';
$route['main'] = '/users/main';
$route['update-account'] = '/users/updateAcc';
$route['sems'] = '/grades/semesters';
$route['allgrades'] = '/grades/allGrades';
$route['grades'] = '/grades/showGrades';
$route['student-profile'] = '/profiles/index';
$route['student-support'] = '/supports/index';
$route['subjects-enrolled'] = '/subjects/index';
$route['enrolled-subjects'] = '/subjects/enrolledSubjects';
$route['add-email'] = '/supports/addEmail';
$route['create-email'] = '/supports/insertEmail';
$route['student-handbook'] = '/supports/studentHandbook';

$route['deactivate'] = '/users/deactivate';

// $route['product/(:any)'] = 'controller/method/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

?>