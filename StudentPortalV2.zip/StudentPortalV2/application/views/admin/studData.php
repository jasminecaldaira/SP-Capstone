<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1 , shrink-to-fit=no">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/data.css')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>

    <script>
		$(document).ready(function(){
			// $.get('users/index_html', function(res){
			// 	$('#studentData').html(res);
			// });

			$(document).on('submit', 'form', function(){
				var form = $(this);
				$.post(form.attr('action'), form.serialize(), function(res){
					$('#studentData').html(res);
				});
				return false;
				$('form').submit();	
			});

			// $(document).on('change', 'form select', function(){
			// 	var form = $(this).parent();
			// 	$.post(form.attr('action'), form.serialize(), function(res){
			// 		$('#studentData').html(res);
			// 	});
			// 	return false;
			// 	$('form').submit();	
			// });
			
		});
	</script>
</head>
<body class="bg-light text-dark">
    <!-- navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/admin-home">Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Content
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/user-management">Admin User Management</a></li>
                            <li><a class="dropdown-item" href="/admin-reset-password">Reset Student Password</a></li>
                            <li><a class="dropdown-item" href="/studData">Student Data</a></li>
                            <li><a class="dropdown-item" href="/admin">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    

    <section class="container mt-5">
        <form class="searchByName" action="users/search" method="post">
            <div class="row height d-flex justify-content-center align-items-center">

                <div class="col-md-8">

                    <div class="search">
                        <i class="fa fa-search"></i>
                        <input type="text" class="form-control" name="name" placeholder="Search By Last Name">

                        <select class="form-outline mb-2 mt-2 form-control" required name="gender" id="">
                            <option value="">Gender</option>
                            <option value="FEMALE">Female</option>
                            <option value="MALE">Male</option>
                        </select>

                        <select class="form-outline mb-4 form-control" required name="course" id="cars">
                                <option value="">Course</option>
                                <option value="BSCS">BS Computer Science</option>
                                <option value="BSIT">BS Information Technology</option>
                                <option value="BEED">Bachelor of Elementary Education</option>
                                <option value="BSED">Bachelor of Secondary Education</option>
                                <option value="BSBM">BS Business Management</option>
                                <option value="BSF">BS Fisheries</option>
                                <option value="BSHM">BS Hospitality Management (formerly BS Hotel and Restaurant Management)</option>
                                <option value="TCP">Teacher Certificate Program</option>
                            </select>
                        <input type="submit" value="Search" class="btn btn-success">
                    </div>
                        
                </div>    
            </div>
        </form>

        <div class="container page-body-wrapper col-md-12 mt-4">
            <div class="table-responsive" id="studentData">
           
        </div>
                    
    </section>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    
</body>
</html>