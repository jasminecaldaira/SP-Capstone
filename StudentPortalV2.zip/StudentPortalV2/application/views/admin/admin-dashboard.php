<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1 , shrink-to-fit=no">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body class="bg-light text-dark">
    <!-- navigation bar -->

    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/admin-home">Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Content
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/user-management">Admin User Management</a></li>
                            <li><a class="dropdown-item" href="/admin-reset-password">Reset Student Password</a></li>
                            <li><a class="dropdown-item" href="/studData">Student Data</a></li>
                            <li><a class="dropdown-item" href="/admin">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

       

    <!-- Showcase -->
    <section class="text-dark px-sm-2 py-2 text-center text-md-start">
        <div class="container">
            <div class="d-md-flex align-items-center justify-content-between text-center">
                <div class="mt-4 ">
                    <h1 class="px-5">Cavite State University - Naic Student Portal</h1>
                    <p class="lead mx-4 my-2 text-center">As an admin, you will be playing a crucial role in the day-to-day operations of the student portal. Your responsibilities will include managing user accounts, resetting student password, and ensuring the smooth functioning of the website.</p>   
                </div>
            </div>
        </div>
      </section>
    
     <section>
        <div class="container">
            <div class="row align-items-center justify-content-between">

                <div class="col-md">
                    <h2 class="my-2 text-center">Welcome, <span class="text-success">Admin!</span></h2>
                    <p class="lead mx-4 text-center">We would like to extend a warm welcome to you as a new member of our admin team. We are excited to have you join our organization and contribute your expertise and skills to help us achieve our goals.</p>
                </div>
            </div>
        </div>
    </section>
      
    <section id="developers" class="p-3">
        <div class="container">
            <div class="row g-4"> 
                <div class="col-12">
                        <div class="card bg-success text-dark">
                            <div class="card-body text-center">
                                <div class="h1">
                                    <a class="bi bi-eye-fill text-light"></a>
                                </div>
                                <h4 class="bg-success text-light my-3">VISION</h4>
                                <p class="card-text lead text-light p-3">The Premier University in historic Cavite globally recognized for excellence in the character development, academics, research, innovation and sustainable community engagement.</p>
                            </div>
                        </div>
                    </div>               
                    
                    <div class="col-12 p-sm-2">
                        <div class="card bg-success text-dark">
                            <div class="card-body text-center">
                                <div class="h1">
                                    <a class="bi bi-cloud-arrow-up-fill text-light"></a>
                                </div>
                                <h4 class="bg-success text-light my-3">MISSION</h4>
                                <p class="card-text lead text-light p-3">Cavite State University shall provide excellent, equitable, and relevant educational opportunities in the arts, sciences and technology through quality instruction and responsive research and development activities.
                                    It shall produce professional, skilled and morally upright individuals for global competitiveness.</p>
                                <span class="text-dark"></span>
                            </div>
                        </div>
                    </div>

                    

                    <div class="col-12">
                        <div class="card bg-success text-dark">
                            <div class="card-body text-center">
                                <div class="h1">
                                    <a class="bi bi-search text-light"></a>
                                </div>
                                <h4 class="bg-success text-light my-3">QUALITY POLICY</h4>
                                <p class="card-text lead text-light p-3">We Commit to the highest standards of education, value our stakeholders, Strive for continual improvement of our products and services, and Uphold the University’s tenets of Truth, Excellence, and Service to produce globally competitive and morally upright individuals.</p>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </section>
    
    <!-- Contact Info -->
    <section class="p-4 text-dark" id="contact">
        <div class="container">
            <div class="col-md">
                <h2 class="text-center">Contact Info</h2>
                <ul class="list-group list-group-flush lead">
                    <li class="list-group-item text-dark">
                        <span class="fw-bold">Main Location: </span> Bucana Malaki, Naic, Cavite
                    </li>
                    <li class="list-group-item text-dark">
                        <span class="fw-bold">Phone Number: </span> (046) 856-0401
                    </li>
                    <li class="list-group-item text-dark">
                        <span class="fw-bold">Email: </span> info@cvsu-naic.edu.ph
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <!-- <h4 class="bg-dark text-light text-center m-0 font-weight-bold"></h4> -->

    <footer class="p-3 text-light text-center position-relative">
        <div class="container">
            <!-- <p class="lead">Copyright &copy; 2022 ---</p> -->
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    
</body>
</html>