<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/updateAcc.css')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/admin-home">Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Content
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/user-management">Admin User Management</a></li>
                            <li><a class="dropdown-item" href="/admin-reset-password">Reset Student Password</a></li>
                            <li><a class="dropdown-item" href="/studData">Student Data</a></li>
                            <li><a class="dropdown-item" href="/admin">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <section class="h-100 h-custom">
    <div class="container py-4 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-lg-8 col-xl-6">
                <div class="card rounded-5 m-4">
                    <div class="card-body p-4 p-md-5">
                        <h3 class="">Update Admin Email Address</h3>
                        <p class="fw-normal">Kindly fill up below fields.</p>
                        <p class="text-success fw-bold"><?php echo $this->session->flashdata('adminEmailUpdated')?></p>
                        <!-- <p class="text-danger fw-normal"><?php echo $this->session->flashdata('notUser')?></p> -->
                        <form class="px-md-2" action="/update-admin-email" method="post">
<?php   
    if (!empty($this->session->flashdata('addAdminError'))) {
        foreach($this->session->flashdata('addAdminError') as $err){   ?>
                          <p class="text-danger fw-bold"><?php echo $err ?></p>
<?php   }   
    }   ?>
                            <div class="form-outline mb-4">
                                <input type="email" id="form3Example1q" class="form-control" placeholder="Current Email Address" name="oldEmail"/>
                            </div>

                            <div class="form-outline mb-4">
                                <input type="email" id="form3Example1q" class="form-control" placeholder="New Email Address" name="newEmail"/>
                            </div>

                            <input type="submit" class="btn btn-success w-100 mb-1"/>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

</body>
</html>