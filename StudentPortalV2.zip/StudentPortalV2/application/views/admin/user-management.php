<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/admin-home">Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Content
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/user-management">Admin User Management</a></li>
                            <li><a class="dropdown-item" href="/admin-reset-password">Reset Student Password</a></li>
                            <li><a class="dropdown-item" href="/studData">Student Data</a></li>
                            <li><a class="dropdown-item" href="/admin">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="m-4">
        <div class="container">    
            <div class="bg-dark">
                <p class="lead fw-bold p-3 text-light">SCHOOL YEAR | SEMESTER</p>
            </div>
            
            <form action="/add-admin" method="post" class="list-group">
                <input type="submit" value="Create Admin" class="list-group-item list-group-item-action fw-bold"/><br>
            </form> 

            <form action="/update-admin-email" method="post" class="list-group">
                <input type="submit" value="Update Admin Email Address" class="list-group-item list-group-item-action fw-bold"/><br>
            </form>            
            
            <form action="/update-adminNumber" method="post" class="list-group">
                <input type="submit" value="Update Admin Phone Number" class="list-group-item list-group-item-action fw-bold"/><br>
            </form>    

            <form action="/add-email" method="post" class="list-group">
                <input type="submit" value="Add Professor Email" class="list-group-item list-group-item-action fw-bold"/><br>
            </form>  
            <li href="/adminList"  data-bs-toggle="modal" data-bs-target="#admins" method="post" class="list-group">
                <input type="submit" value="Admin List" class="list-group-item list-group-item-action fw-bold"/><br>
            </li>   
            

            <li class="list-group">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle col-12" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Update Current Semester
                    </button>
                    <div class="dropdown-menu text-center col-12" aria-labelledby="dropdownMenuButton">
<?php   foreach($sems as $row){ ?>

            <form  action="/subjects-enrolled" method="post">
                <input type="hidden" name="pick-year" value="<?=$row['schoolyear']?>"/>
                <input type="hidden" name="pick-sem" value="<?=$row['semester']?>"/>
                <input type="submit" value="<?=$row['schoolyear']?> - <?=$row['semester']?>" class="dropdown-item"/><br>
            </form>
<?php   }   ?>
                    </div>
                </div>
            </li>
        </div>
    </section>

    <!-- Modal -->
    <div class="modal fade" id="updateSem" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">List of Admins</h5>
                </div>
                <div class="modal-body text-justify">
                    <!-- <ul class="list-group list-group-flush"> -->
<?php   foreach($admin as $ad){ ?>
    <div class="input-group mb-3">
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Dropdown button
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <a class="dropdown-item" href="#">Something else here</a>
            </div>
        </div>
        <!-- <form action="/updateSem" method="post">
            <input type="hidden" name="sem" value="">
            <input type="hidden" name="year" value="">
            <input type="submit" value="Deactivate" class="btn btn-danger" type="button">
        </form> -->
    </div>

<?php   }   ?>
                    <!-- </ul> -->
	    		</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="admins" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">List of Admins</h5>
                </div>
                <div class="modal-body text-justify">
                    <!-- <ul class="list-group list-group-flush"> -->
<?php   foreach($admin as $ad){ ?>
    <div class="input-group mb-3">
        <li type="text" class="list-group-item form-control" aria-describedby="button-addon2"><?=$ad['emailaddress']?></li>
        
        <form action="/deactivate" method="post">
            <input type="hidden" name="email" value="<?=$ad['emailaddress']?>">
            <input type="submit" value="Deactivate" class="btn btn-danger" type="button">
        </form>
    </div>

<?php   }   ?>
                    <!-- </ul> -->
	    		</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>
</html>