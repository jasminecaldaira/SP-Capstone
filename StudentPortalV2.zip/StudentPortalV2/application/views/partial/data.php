<?php
    // var_dump($products);
    
?>

<table class="table table-striped">
    <thead class="bg-success text-light">
        <tr class="text-center">
            <th>Student Number</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email Address</th>
            <th>Contact Number</th>
        </tr>
    </thead>

    <tbody>
<?php   foreach ($products as $product) {   ?>
        <tr scope="row" class="text-center">
            <td><?=$product['studentNumber']?></td>
            <td><?=$product['firstName']?></td>
            <td><?=$product['lastName']?></td>
            <td><?=$product['emailaddress']?></td>
            <td><?=$product['mobilePhone']?></td>
        </tr>
<?php   }   ?>
    </tbody>
</table>