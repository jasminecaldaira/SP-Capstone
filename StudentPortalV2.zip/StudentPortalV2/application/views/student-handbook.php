<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1 , shrink-to-fit=no">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/hb.css')?>">
</head>
<body class="bg-light">
    <!-- navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/main">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" aria-current="page" href="/student-support">Student Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" aria-current="page" href="/handbook">Student Handbook</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo ucwords($this->session->userdata('shortName'))?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/student-profile">Student Profile</a></li>
                            <li><a class="dropdown-item" href="/enrolled-subjects">Enrolled Courses</a></li>
                            <li><a class="dropdown-item" href="/class-schedule" target="_blank">Class Schedule</a></li>
                            <li><a class="dropdown-item" href="/sems">List of Grades</a></li>
                            <li><a class="dropdown-item" href="/">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

        <!-- Button trigger modal -->
        <div class="container">
            <div class="row">
                <div class="col-xl-12 mb-3 mb-lg-5">
                    <div class="card mt-4">
                        <div class="d-flex card-header justify-content-between">
                            <h5 class="me-3 mb-0">Student Handboook Contents</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <!--List-item-->
                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#foreword">Foreword</a></h6>
                                        </div>
                                    </div>
                                </li>
                                
                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#ext">Research and Extension Services</a></h6>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#admin">Administrators (1906 - Present)</a></h6>
                                        </div>
                                    </div>
                                </li>
                                
                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#vis">University Vision, Mission and Objectives</a></h6>
                                        </div>
                                    </div>
                                </li>


                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#gen">General Academic Rules and Regulations</a></h6>
                                        </div>
                                    </div>
                                </li>

                                

                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#susp">Suspension Of Classes </a></h6>
                                        </div>
                                    </div>
                                </li>

                                
                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#isko">University Scholarship</a></h6>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#revi">Curriculum Revision</a></h6>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        <!-- <img class="avatar rounded-circle" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" alt="logo"> -->
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#accre">Program Accreditation </a></h6>
                                        </div>
                                    </div>
                                </li>


                                <li class="list-group-item pt-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 my-3">
                                        <!-- <img class="avatar rounded-circle" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" alt="logo"> -->
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-0"><a class="text-muted" href="#"  data-bs-toggle="modal" data-bs-target="#spec"> Specific Policies and Guidelines on Admission, Transfer, Change  Subjects, Leaves, Dropping, Grades and Grading System, Academic Deliquency, and Graduation  </a></h6>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="spec" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Specific Policies and Guidelines on Admission, Transfer, Change  Subjects, Leaves, Dropping, Grades and Grading System, Academic Deliquency, and Graduation </h5>
                            </div>
                            <div class="modal-body text-justify">
<b> Section 1. <u>Policies and Guidelines for the Science High School (SHS).</u> </b> Unless otherwise changed
in accordance with the Board of Regent’s action, SHS shall offer a Science Curriculum with the rules and
regulations discussed below. Any portion or all of these rules and regulations may change any time as
deemed necessary by the Board of Regents upon endorsement of the University Academic Council. <br> <br>
<b>a) Admission Requirements.</b> Graduates of any private and public elementary school may be
admitted in the Science Curriculum upon presentation and/or fulfillment of the following
requirements: <br> <br>
1. Submission of Form 138 (Report Card); <br> <br>
2. Certification of good moral character signed by the Principal/Guidance Counselor; <br> <br>
3. Certification of physical and mental fitness from the University Physician; <br> <br>
4. Payment of P100.00(may be changed without prior notice) entrance examination fee;
And <br> <br>
5. Passing the following test: <br> <br>
5.1 Mental Ability Test (MAT) <br>
5.2 Science and Math Aptitude Test (SMAT) <br>
5.3 Essay/Communication Test <br> <br>
<b>b) General Retention Standards and Grade Requirements.</b> Student other than those who
received full or partial scholarship must maintain academic standards as follows: <br> <br>
1. GPA of not lower than 78% <br>
2. Weighted average in Mathematics, Science and Scientific research
of not lower than 78%; and <br>
3. No failing grades in any subject. <br><br>
Students who failed to maintain the academic standards shall be
denied readmission. <br><br>
<b>c) Transfer Students.</b> Transfer to SHS from other school is not allowed unless the curriculum of
the high school where the student comes from is exactly the same as that of the SHS. If the
student meets this requirement, a screening committee shall be created by the SHS
Principal for the purpose of determining the possibility and appropriateness of transfer. <br><br>
<b>d) Types of Scholarships.</b> Starting in the second year, students may be entitled to scholarships.
There shall be two types of scholarship: <br><br>
<b>1. Full Scholarship</b> – GPA of 90% or better in all academic subjects at
the end of the school year; and weighted average grade of 90% or
better in Science, Mathematics and Scientific Research. <br>
<b>2. Partial scholarship</b> - GPA of 88% to 88.99 % in all academic subjects
at the end of the school year; and GPA of 88% to 89.99% in Science,
Mathematics and Scientific Research. <br><br>
A scholar, whether full or partial must: <br><br>
 Not have a grade lower than 85% in any of the subjects
taken; <br><br>
 Abide by the provision of the University Norm of Conduct
for students. (The scholarship is forfeited if the student is
involved in any form of misdemeanor); and <br><br>
 Submit notice or any change of legal guardian and residence
while studying in the University SHS. <br><br>
<b>e) Scholarship Privileges.</b> The scholar shall receive the privileges listed below. These privileges
may be changed at any time as deemed necessary by the Board of Regents: <br> <br>
<b>1. Full scholarship <br> <br>
1.1 P500.00 monthly stipend <br>
1.2 P500.00 yearly book allowance <br> <br>
2. Partial scholarship <br> <br>
2.1 P300.00 monthly stipend <br>
2.2 P500.00 yearly book allowance</b> <br> <br>
<b>f) Student Conduct and Discipline.</b> Students of SHS shall be covered by the University Student’s
Code of Conduct as astipulated in Rule VIII of the CvSU Manual of Operation 2009 Vol. 1. <br> <br>
<b>g) Granting of Awards and Honors</b> <br> <br>
<b>A. For Non-Graduating Students (First to Third Year)</b> <br>
1. Any member of the non-graduating classes shall be a candidate for honor if
he/she meets the following requirements: <br> <br>
1.1 Weighted average grade of not lower than 88% in Science,
Mathematics and Research and a GPA of not lower than 85% during
the academic year. <br>
1.2 No grade lower than 83% in any subject in any grading period. <br>
2. Deserving students shall be awarded first, second, and third honors. <br>
3. Placement of candidates in the honor roll shall be based on the composition
academic performance and co-curricular activities (Appendix A). The weight
of academic performance and co-curricular activities are 85% and 15%
respectively; and <br>
4. Candidates who qualify gor honors shall receive medals and certificate of
recognition. <br>
<b>B. For Graduating Students </b><br>
1. Members of the graduating class can be candidates for honors provided
they have: <br>
1.1 Completed the curriculum in four years; <br>
1.2 A GPA of not lower than 85% from first to fourth year; <br>
1.3 No grade lower than 83% in any subject in any grading period from
first to fourth year. <br> 
1.4 Have conducted themselves in conformity with the Student Norm of
Conduct. <br>
2. Qualified students shall be ranked based on the composite academic
performance and co-curricular activities (Appendix A) from first to fourth
year. <br> <br>
Top five of the graduating class with 50 members shall be awarded
Valedictorian; Salutatorian; First Honorable Mention; Second Honorable
Mention; and Third Honorable Mention respectively. However, top 5 of the
graduating class with less than 50 members shall be awarded First, Second,
Third, Fourth and Fifth Honors, respectively. <br> <br>
3. The weights for academic performance and co-curricular activities are 85%
and 15%, respectively. <br>
4. Special awards shall be granted to deserving students based on the
guidelines given by sponsoring agency. <br>
5. Selection Committee will be composed of all teachers who handled the
subjects of the graduating class however; any teacher who is related up to
the second degree of affinity or consanguinity to any candidate for honors
shall not be allowed to sit as member committee. <br>
6. In case of a tie, candidates may both be declared for their honor ranking, for
example both as valedictorians, salutatorians, etc. <br>
7. Honor students shall be endorsed by the Principal and/ or Officer-in-Charge
to the College/Campus Academic Council and University Academic Council,
subsequently for approval. Official announcement shall be done thereafter. <br>
8. Protest, if any, should be filed through a formal written communication by
the concerned student and/or parent/guardian to the College/Campus Dean
within tow (2) working days after the selection. It should be settled during
the College/Campus Academic Council Meeting. <br> <br> 
<b> Section 2.<u> Policies and Guidelines for the Degree and Non-Degree Programs. </u> </b> Unless otherwise
specified, the policies and guidelines below apply only to both the degree and the non-degree
programs of the University. <br><br>
<b>a) Admission and Registration</b>
<b>1. Admission of New Students. </b> All applicants for the degree
programs shall pay a P 150.00 (may be changed without prior
notice) entrance examination fee; pass the entrance
examination given by the University and meet the following
qualifications: <br>
1.1 graduate of any public or DECS recognized private high
school; <br>
1.2 Physically and mentally fit to study; and <br>
1.3 Possess a good moral character as certified by the Hi9gh
School Principal. <br><br>
Individual’s colleges and campuses may institute their own
requirements specific to their programs provided these
requirements are endorsed by the University Administrative
Council and approved by the Board of Regents. <br>
<b>2. Admission of Foreign Students.</b> Foreign students are required
to: <br><br>
2.1 submit an approved permit to study from the
concerned embassy; <br>
2.2 pay a non-refundable foreign student fee of $30.00;
(may be changed without prior notice) <br>
2.3 submit a certificate of English proficiency from the department of languages and
humanities; <br>
2.4 Police Clearance form country of origin. <br><br>
<b>3. Admission of Transfer Students.</b> Transfer students from other schools and
college/universities are requires complying with the following requirements: <br><br>
3.1 Submit the following: <br><br>
3.1.1 Certified true copy of Transcript of Records; <br><br>
3.1.2 GPA should be 2.00 better for programs with licensure/board examinations
(approved per BOR Res. No. 51 s 2005) <br><br>
3.1.3 Honorable Dismissal; <br><br>
3.1.4 two (2) copies of 1” x 1” ID pictures; <br><br>
3.1.5 Certificate of Good Moral Character certified by the guidance counselor/dean from
the last school attended <br><br> 
3.1.6 NBI Clearance; <br><br>
3.1.7 Passing the required entrance examination (approved per BOA Res. No. s.2005) <br><br>
3.2 Must have passed the interview conducted by the Screening Committee of the College
where student intends to enroll the course. <br><br>
In addition, the respective colleges may require a background (inquiry) check on the
student who request for transfer to the University. <br><br>
Students who qualify for transfer may apply with their respective College Registrars for
advanced credit for equivalent courses upon presentation of transcript of records and
authenticated proof of equivalency of course. <br><br>
Note: No transferee shall be admitted after the 2nd year level for programs ith
board/licensure examinations. (Approved per BOA Res. No. 2005 Oct. 18, 2005) <br><br>
<b>4. Shifting to other programs.</b> Students who intend to shift to another University program must
accomplish a prescribed from for the purpose to be approved by the Dean od the College where they
want to shift to, not later that ten (10) working days before the start of the regular registration period. A
copy of the approved application for shifting should be forwarded by the Dean concerned to university
Registrar Office. <br><br>
Students pursuing degree programs may be allowed to shift to non-degree programs upon
approval of their application for shifting. <br>
Students pursuing non-degree program may be allowed to shift to degree programs offered by
the College after satisfying the following requirements except for ladderized programs: <br><br>
4.1 GPA of 2.0 or better<br>
4.2 Submission of approved application form and other supporting
documents; and <br>
4.3 Passing the required entrance examination. <br><br>
<b>5. Cross Registration.</b> Cross-registrants from other educational institution should have been written
permission from their school registrar r to be presented to the CvSU Registrar. The permit shall state the
subjects and the total number of units the student is allowed to cross-register and that the University
shall be the venue for the course to be registered. <br><br>
For courses with pre-requisites, the cross registrant shall be required to present an
authenticated proof of equivalency of course and description of the required course. <br><br>
CvSU students who are planning to cross-register courses with other institutions should have a
written permit from their College and the University Registrar. <br><br>
Students planning to cross-register in other University College or Campus shall be allowed inly
under the following conditions: <br><br>
5.1 The course(s) to be cross-registered should have exactly the same description as the one being
offered in other college or campus where the student plans to cross-register; <br><br>
5.2 Must have written permit from their respective College Registrars and finally the University
Registrar; and <br><br>
5.3 Students are allowed to cross-enroll a maximum of six (6) units only for the entire program. <br><br>
<b>6. Late Registration.</b> The period for the late registration shall be seven school days after the regular
registration schedule. No late registrants will be entertained after this period. <br><br>
Undergraduate degree and non-degree students who register during the authorized period for
late registration shall be charged a fine of P100.00 (may be changed without prior notice), regardless of
the number of days their registration is delayed and the number of units that a student is carrying
during a particular term. <br><br>
Any student whose registration has been approved by the Registrar during the registration
period but has not settled at least the first installment of his/her fees shall also be charged fine for late
registration. The Cashier’s Office indicates the fine in the registration form of the student upon payment
of fees. <br><br>
No late registration shall be entertained for the summer program. <br><br>
Individual colleges and campuses may purpose and implement other academic policies
consistent with the general guidelines on academic rules and regulations and approved by the Board of
Regents. <br><br> 
<b>7.General Enrollment Guidelines and Procedures.</b> Three months prior to each registration period, the
university Registrar’s Office shall outline the general enrollment guidelines and procedure or any
revision thereof and present these to the University Academic Council for approval. No modification of
the approved guidelines and procedures shall be implemented unless approved by the Office of the Vice
President for Academic Affairs. <br><br>
<b>8. Schedule of Payment.</b> All fees may be paid in cash or installment. The schedule of payment for
installment is as follows: <br><br>
8.1 50% upon registration<br><br>
8.2 25% two weeks before the midterm examination<br><br>
8.3 25% two weeks before the final examination<br><br>
<b>9. Refund of Fees.</b> Student who withdraws their registration from the University after a period of not
more than three weeks or fifteen days of regular classes shall be refunded in full except the medical and
dental fees. No refund shall be given to those who withdraw after this period. <br><br>
<b>Implementing Guidelines*</b><br><br>
<b>9.1 Nature of Refundable and Non-refundable Fees </b><br><br>
9.1.1 Student fees that are considered refundable are those that accrue and/or deposited to the
trust accounts of the University 164 shall be limited to the following: <br><br>
9.1.1.1 Tuition<br><br>
9.1.1.2 Laboratory Fee<br><br>
9.1.1.3 Student Resource fund <br><br>
9.1.1.4 Student Facilities Development Fund <br><br>
9.1.1.5 Library<br><br>
9.1.1.6 College Publication<br><br>
9.1.1.7 Guidance Fee<br><br>
9.1.1.8 SCUAA/Athletic Fee<br><br>
9.1.2 In addition, miscellaneous fees that are payable and maintained in the deposit accounts of
the Office of Student Affairs shall also be considered refundable such as student handbook, cultural fee
and student publication. <br><br>
9.1.3 Other fees not specifically provided above shall be deemed non-refundable. These include
payments made for the following: These include payments made for the following: <br><br>
9.1.3.1 Identification Card<br>
9.1.3.2 Medical and Dental<br>
9.1.3.3 Registration<br>
9.1.3.4 Insurance<br>
9.1.3.5 Mutual Aid<br> <br>
9.1.4 The deposit paid by the student during his initial enrolment in the University is likewise refundable.
However, a student/group of students may opt to donate the same to the university through the Office
of Alumni Affairs. <br><br>
<b>9.2 Amount Refundable. </b>
The amount of refundable fees that can be availed by the students shall correspond to the total
amount actually paid in cash during enrollment, limited to specific fees stated in Nos. 9.1.1, 9.1.2, and
9.1.3, respectively. <br><br>
<b>9.3 Reason for Refund </b> <br><br>
9.3.1 The reason for which refund of school fees other than deposit are allowed shall include
and of the following: <br><br>
9.3.1.1 Withdrawal of registration<br>
9.3.1.2 Dropping of enrolled subject<br>
9.3.1.3 Scholarship<br>
9.3.1.4 Overpayment<br> <br>
9.3.2 For reason of “overpayment”, refund of the excess amount shall be considered only if the
total fees for the semester is paid in “cash” or “in full” during registration. If “in installment”, the excess
amount shall be credited to the students for the next payment period. <br><br>
9.3.3 Withdrawal/refund of deposit shall be allowed only for reasons of graduation from the
University or transfer to another school as the case maybe. <br><br>
<b>9.4 Period of Refund </b> <br><br>
9.4.1 The period of refund within which refund of school fees as those enumerated under 9.1.1,
except “deposit”, shall be on a semestral basis and to be made within three (3) weeks or 15
school days from the start of regular classes as indicated in the approved school calendar. <br>
9.4.2 In the event that the opening or first day of regular classes is postponed to a later date
than what is explicitly provided in the school calendar as agreed/approved by the University
Administrative Council, the inclusive period mentioned in No. 9.4.1 shall likewise be observed. <br>
9.4.3 If the student opts to claim for refund his paid “deposit”, the same shall be allowed within
15 working days from the date of graduation of from the date the honorable dismissal is issued
by the University Registrar. <br>
<b> 9.5 Procedure for Refund </b> <br><br>
9.5.1 Students who intend to claim or request for refund of school fees paid during enrollment
shall accomplish the prescribed application form. <br>
9.5.2 The accomplished application form must be filed/received at the Accounting Section
within the period stated under No. 9.4.1 above. In no case shall application for refund be
entertained after said period. <br>
9.5.3 Application for refund must be supported with authenticated photocopy of “Certificate of
Registration” and other documants depending upon the reason stated in the application as the
following: <br><br> 

<table class="table table-striped">
    <tr>
        <th>Reason For Refund</th>
        <th>Supporting Documents</th>
    </tr>
    <tr>
        <td>Withdrawal of Registration</td>
        <td>Certificate of Withdrawal of Registration to be issued by the Registrar Office</td>
    </tr>
    <tr>
        <td>Dropping of Enrolled Subjects</td>
        <td>Dropping From duly signed by the Instructor/s concerned and approved by the Dean of the College that offers the subject</td>
    </tr>
    <tr>
        <td>Scholarship</td>
        <td>Certification of Scholarship to be issued by the Dean of Students Affairs</td>
    </tr>
    <tr>
        <td>Overpayment</td>
        <td>Free Assessment From issued by the Registrar’s Office</td>
    </tr>
</table>

 <br> 
Claim for refund of paid deposit must be supported with authenticated copy of graduation
clearance, if the reason is graduating in the university and/or authenticated copy of” Honorable
Dismissal”, if the reason is transfer to another school. <br><br>
9.5.4 The Accounting Section shall evaluate the application filed by the students. If found in
order, approval shall be made by the Accountant. Otherwise, the application should be returned
to the student, through the Office of Student Affairs, with notation as to the reason foe
disapproval. <br>
9.5.5 Upon approval, the Accounting Section shall prepare the corresponding disbursement
voucher for processing. As much as possible, refund of student fees should be in payroll form
and to be paid in cash. <br>
9.5.6 A student / group of students intending to donate their paid deposit to the university shall
execute a “waiver” or “Deed of Donation” specifying the purpose for which the donated amount
shall be utilized. <br>
9.5.7 Completed/updated records of refund made every semester shall be maintained in the
accounting Section for reference and other purposes. <br>
9.5.8 Refund of fees paid directly to the Office of Student Affairs shall be governed by a set of
separate rules to be prepared by the same office. <br><br>
<b>10. Issuing of Grades to Students without Examination Permit*.</b> <br><br>
10.1 Faculty members shall sign the examination permits of the students during the final
examination. Students who have no permit shall be allowed to take the examination but the
faculty member should see to it that he/she has properly recorded the names of these students. <br> <br>
10.2 The names of students without examination permits shall be printed / written below the
grading sheets and shall be labeled “GRADES WITHHELD” written in red ink with no credits
equivalent under the column “Credit” until such time that students are able to present their
examination permits shall the word “no exam permit be replaced stating class cards shall be
kept by the concerned faulty member while the students are not yet cleared. <br><br>
10.3 The University Registrar’s Office shall them issue a Certification of Grades upon clearing.
The students should present the Certification to the faculty member(s) concerned before issuing
their class cards and to their Registration Adviser(s) for posting of grades. The University
Registrar’s Office shall also provide the list of students who were cleared from their obligations
for consistency in recording. <br> <br>
If the Faculty member concerned is no longer connected with the University, he/she shall
entrust the distributed class card to the College Registrar. <br><br>
10.4 The Accounting Office shall post the names of students who have not been cleared of
accountabilities before the start of the succeeding registration period. <br><br>
10.5 The students should present their clearance before they can enroll in the succeeding
semester. <br><br>
<b>b) Academic Load.</b> No student shall be allowed to take more than a maximum credit unit per
semester. A graduating student may be allowed to enroll more than the maximum allowable
credits units not to exceed 26 units during the last two semester of his course provided that he
has a GPA of 2.50 or better in the previous two semester as certified by the University Registrar.
A graduating student petitioning for registering up to maximum allowable academic load must
secure a certification from the University Registrar that he is a graduating student. <br><br>
During summer program, a student may be allowed a maximum of three (3) lecture
courses or one with laboratory and one lecture course. No student will be allowed to register
with two (2) laboratory courses except when one is a co-prerequisite of the other. <br><br>
<b>c) Class Attendance.</b> A student who has been absent from classes for at least two (2)
consecutive meeting must obtain an excuse slip form the Office of Student Affairs and present
this to the instructor concerned on the day he returns to class. <br><br>
Excuses are for time missed only. Work covered by the class during the absence shall be
made up within reasonable time to the satisfaction of the instructor. <br><br>
If a student has been absent in 20 percent of the time schedule devoted to the class
without justifiable reasons, he/she shall e dropped from the rolls. If the majority of these
absences are not excused and the student’s performance is poor, he/she will receive a grade of
“5.00”. <br><br>
<b>d) Changing/Adding/Dropping of Course/s.</b> Transfer to other section must be made for valid
reasons only such as conflict in schedule. <br><br>
No change in matriculation will be allowed after three (3) weeks of regular classes.
Change in subject can be accomplished by filling up a changing/dropping from duly noted by the
registration adviser and the instructor concerned and approved by the College Dean concerned. <br><br>
A student, with the consent of the instructor concerned and the Den of the college
where he is enrolled, may drop a subject by filling a prescribed form for the purpose. No
dropping of subject is allowed after the midterm examination ha elapse except due to illness
and other justifiable reasons. <br><br>
Dropping of courses/subjects shall only be made for valid reasons, only such cases as
the course is not needed, ill-advised, conflict in schedule, registered higher course without
passing the prerequisite course(s) and registered major course without passing all the required
basic course except in cases where the basic courses are offered in a semester concurrent with
the major course. <br><br>
Dropping of course(s) shall be made official by filling a prescribed form at the Office of
the College Registrar. <br><br>
Dropping of courses shall be made within six weeks after the start of regular classes. <br><br>
Dropping of courses beyond this period shall not allow except due to illness or change of
residence. <br><br>
A student shall maintain the minimum 12-unit load even after dripping certain course.
Refund for dropped courses shall be made within three weeks or 15 days after the start
of regular classes. <br><br>
Students who failed to drop within the prescribed period are considered officially
enrolled and are therefore covered by all the provisions applicable to enrolled students. <br><br>
A student shall be notified by the University Registrar to drop a course subject to the 
following circumstances: <br><br>
1. Registered higher courses without passing the pre-requisite course(S); and <br>
2. Registered major course without passing all the required basic courses except in cases
where the basic courses are offered in a semester concurrent with the major course. <br><br>
If a student officially drops the course before 75% of the hours prescribed for
the course have elapsed, the instructor concerned may not give the student a
corresponding grade and he word “Dropped” shall be reflected in the instructor’s class
record. If a student drops the course after 75% of the required hours has elapsed, a
corresponding grade on his performance shall be reflected in the grading sheet and
recorded in the student’s Permanent Record for that particular semester/term. <br>
A student is considered dropped if the last day of his three week consecutive
absences occurs on the schedule last day dropping of courses.
<b>e) Re-enrollment of Subjects.</b> No student shall be allowed to repeat or re-enroll a subject for more than
three (3) times. A student who fails a subject for the third time shall be permanently disqualified from
further registration in the University. <br><br>
After the student has taken the subject for the second time and fails, the registration adviser
shall be informed by the Registrar regarding the status of the student. <br><br>
<b>f) Prerequisite Subjects.</b> A student shall not be allowed to register an advanced subject without
passing/satisfying the requirements of the prerequisites subject(s) specified in the curriculum. Passing
grades obtained in the advanced courses without first satisfying the prerequisites shall be considered
null and void by the University Registrar. <br><br>
Concurrent registration of the prerequisites and an advanced subject is not allowed.
However, registration of two (2) major courses determined to be co-requisites by the
college department concerned may be allowed. <br><br>
<b>g) Leave of Absence.</b> A student who is granted leave of absence (LOA) within 75% of the time devoted
to a semester/term shall be given a corresponding grade by the instructor concerned for record purpose
only but this will not be reflected in his Permanent Record. A student granted leave of absence due to
illness or other justifiable reasons after 75% of the time has elapse shall be given numerical grade
depending on his/her class performance. <br><br>
<b>h) Honorable Dismissal.</b> Honorable dismissal shall be issued by the University Registrar to a student who
stopped schooling in the University Registrar to a student who stopped schooling n the University
provided that he was not found guilty or misdemeanor defined under the University Students’ Norm of
Conduct. If a student left the University for Reasons of misdemeanor and/or academic delinquency, no
certification of honorable dismissal shall be issued. <br><br>
<b>i) Grades and Grading System.</b> The University shall adopt the numerical grading system of “1.00” to
“5.00” where “1.00” is the highest and “5.00” is a failing grade. The system of grading is as follows: <br><br>
1.00 ------------------- Excellent (Highest Grade) <br><br>
1.25<br><br>
1.50 ----------------- Very Good<br><br>
1.75<br><br>
2.00 ---------------- Good<br><br>
2.25<br><br>
2.50 ---------------- Satisfactory<br><br>
2.75<br><br>
3.00 --------------- Passing Grade<br><br>
4.00 --------------- Conditional Grade has to be removed by taking a removal examination either to
obtain a grade of “3.00” or slide to “5.00” <br><br>
“Inc.” --------------- Grade of Incomplete. The student is passing but has not completed other
requirements of the course. <br><br>
5.00 ---------------- The student failed the course. The numerical grade of “5.00” must be written
in red ink by the teacher. <br><br>
Each College shall endeavor to formulate and adopt a uniform method or system of
assigning grades to scores and the assignment of weights to different types of test,
requirements, laboratory exercises and the like. This should be forwarded to the Vice President
for Academic Affairs for his review and corrections before final adoption of the College
concerned. <br><br>
College Deans shall include the grading system in their orientation of new teachers and
each teacher should explain the grading system to his students at the start of the classes each
semester/term. <br><br>
No teacher shall be allowed to adopt a grading system different from the one being
implemented by his College where he belongs. <br><br>
<b>j) Honor Students.</b> Students who obtain a GPA of “1.75” to “1.51” in a semester shall be listed in the
Vice President for Academic Affairs’ Honor Students List while those who obtain GPA of “1.50” to “1.00”
shall be included in the Presidents’ List of Honor Students. <br><br>
<b>k) Removal/Completion of Grades of “4.00” and “Inc.”</b> The grades of “4.00” and “Inc.” may be removed
through any of the following: <br><br>
1. without Paying the Special Examination Fee. A grade of “4.00” may be removed within one
(1) year by taking the examination during the regular schedule for removal examinations. <br><br>
An “Inc.” grade may be removed by completing the requirements for the subject any
time within one (1) year provided that he/she is currently enrolled. <br><br>
<b>3. Paying the Special Examination Fee.</b> A grade of “4.00” may be removed by a special
removal examination administered any time upon payment of special examination fee of
P10.00 per unit (may be changed without prior notice) and upon presentation of duly
approved permit to the instructor concerned. <br><br>
<b> l) Obtaining Permit for special Removal Examination.</b> A student fills a request form available from the
University Registrar Office to take special examination addressed to the College Dean concerned stating
among others, the reason(s) why he was not able to take the examination during the schedule
examination period; the request should be duly endorsed by his registration adviser and approved by
the College Dean concerned. The Dean approves the request and the student presents this for payment
to the University Cashier. <br><br>
Upon payment of fees, the student reports to the Instructor/Professor concerned and presents
is permit with the receipt of payment to rearrange for the date of the removal examination. <br><br>
After a student has taken the removal examination or has completed all the
requirements, his final grade shall be recorded by the teacher concerned in the prescribed
completion report form accomplished in quadruplicate. The report from shall be forwarded to
the Department Chairperson for recommendation, then to the Dean for approval, and finally to
the registrar. The report for removal examination should forward to the Registrar within ten (10)
days after the examination. <br><br>
The removal examination for Grades of “4.00” obtained in the current semester shall
not be scheduled during the regular final examination period of that semester. The final Grade
of “4.00” shall be reflected first in the student’s record before this can be removed. <br><br>
<b>m) Automatic Grade of “5.00” from Grades of “4.00” and “Inc.”</b> If the a student is unable to remove his
grade of “4.00” through a removal examination or has not completed the requirements to remove his
grade of “Inc.” within one year from the last semester/term when these were obtained, these grades
shall be automatically converted to grades of”5.00” by the University Registrar. <br><br>
<b>n) Rules on Scholarship Delinquency.</b> The CvSU shall promulgate suitable and effective guidelines on
academic deficiencies. Any students whose scholastic performance in subjects enrolled for the semester
in “Incomplete (Inc.)” or below the passing mark of “3.00’ and/or who dropped the subjects for
unjustifiable reasons shall be subjected to the rules on academic deficiencies below: <br><br>
<b>1. Types of academic deficiency</b><br><br>
<b>1.1 Warning.</b> Any student who, at the end of the semester is found to have dropped the course
or obtained an incomplete, conditional or failing grades or a combination thereof in 30% - 50% of the
enrolled subjects shall fall under this category. The students shall be warned by the Office of the
College/ University Registrar to improve his/her academic performance. <br><br>
Warning status for two consecutive semesters place the student on the probationary
status in the succeeding semester. <br><br>
<b>1.2 Probation.</b> Any student who at the end of the semester is found to have dropped the course
or obtained an incomplete, or grades below “3.00’ or a combination thereof in 51% or more of the
enrolled subjects shall be placed under probationary status. Academic load of students under this
category for the succeeding semester shall be limited to 15 units only. <br><br>
If he/she incurs probationary status for two consecutive semesters, he/she shall be classified
under the disqualification status to 15 units only. <br><br>
Probationary status maybe removed by obtaining a grade of “3.00”in 75% of the enrolled
subjects. <br><br>
<b>1.3 Disqualification.</b> Any student who, at the end of the semester failed in 75% or more of the
enrolled subjects shall be rendered ineligible to enroll for one semester. He/she shall be allowed to carry
an academic load of not more than 15 units when he/she enrolls in the succeeding semester. <br><br>
A student who re-enrolls in the University after a disqualification for a semester should
not incur failure in 50% of the enrolled subjects return. A disqualification of another semester
will be meted out for obtaining the failing grades<br><br>
A student shall only be allowed two-disqualified status after which he shall no longer be
eligible to continue his studies in the University. <br><br>
A student who obtained grades on “Inc.” or “4.00” or a combination in 100% of subjects
registered shall not be allowed to enroll in any subject in the succeeding semester but shall be
advised to enroll on residency to complete all the course requirements. <br><br>
2. A student who has 21 units or fewer academic units remaining in the curriculum will be allowed to enenroll despite reaching the academic deficiency limits. <br><br>
3. No readmission of disqualified students shall be considered by the Office of the University Registrar
without favorable recommendation of the Readmission Committee composed of the College Registrar
as Chairman, the Guidance Counselor, the Chairman of Department where they are enrolled and one
faculty member designated by the College Dean concerned as members. <br><br>
4. The Office of the University Registrar shall notify the student of his academic deficiency status every
end of the semester or before enrollment. <br><br>
<b>o) Honorable Dismissal.</b> <br><br>
1. Honorable dismissal is voluntary withdrawal from the University. <br><br>
2. The statement indicates that the student withdraws in good standing as far as character and
conducted are concerned. <br><br>
3. All indebtedness must be settled before a statement of honorable dismissal shall be issued. <br><br>
4. Any subject who leaves the University by reason of expulsion due to disciplinary action shall
not be entitled to honorable dismissal. <br><br>
5. If the student has been dropped from the rolls of the University on the account of poor
academic performance, a statement to his effect shall be included in the honorable dismissal. <br><br>
<b>p) Graduation.</b> Student shall be recommended for graduation upon satisfaction of all academic and
other requirements prescribed for graduation. <br><br>
Two weeks after the registration for the second semester, the College Dean shall submit to the
University Registrar a list of tentative candidates for graduation. The University Registrar, in consultation
with the Deans concerned shall review the academic record of each candidates to a certain whether any
candidate in the said list has any deficiency that may disqualify him from the list. <br><br>
If there is any question regarding a candidate, his name shall not be deleted from the list of
candidates but a list of tenable deficiencies shall be written below his name. <br><br>
Ten weeks before the end of the semester, the Registrar shall publish a complete list of duly
qualified candidates for graduation. <br><br>
All candidates for graduation shall have their deficiencies cleared and their records completed
on or before the midterm examination except in those subjects in which they are currently enrolled. <br><br>
Submission of the final grades of graduation students shall be within ten working days after the
final examination. <br><br>
A month before the scheduled date of graduation, the respective Academic Councils of each
Colleges/Campus or their Committees on Curriculum and Instruction shall act on the status of
graduating students and endorse to the University Academic Council the names of students who are
sure to graduate and indicating the deficiencies that can be corrected by graduating students within
reasonable time to be set the University Academic Council. <br><br>
A student shall be allowed to graduate from the University upon completion of at least one year
of residence immediately prior to graduation. <br><br>
A student who does not pay the required graduation fee shall not be issued a diploma,
certificate or transcript. <br><br> 
A graduating student shall not be declared graduate from the University unless he attends the
Commencement Exercise. A graduating student may graduate in absentia only upon prior request for
valid reason (s) addressed to the dean of the college where the student will earn his degree. <br><br>
A graduating student who is unable to attend the commencement exercise and who failed to file
a request for graduation in absentia shall not be declared graduate and shall be required to attend the
next commencement exercises. <br><br>
<b>Granting of Honors.</b> The following requirements must be satisfied to be considered and
awarded as honor student: <br><br>
1. The Grade Point Average (GPA) obtained must be” <br>
1.00 – 1.21 – Summa Cum Laude (With highest honors) <br><br>
1.22 – 1.45 – Magna Cum Laude (With high honors) <br><br>
1.46 – 1.75 – Cum Laude (With honors) <br><br>
2. The lowest grade obtained in all courses including NSTP should be: <br>
 2.00 – Summa Cum Laude (With highest honors) <br><br>
 2.25 – Magna Cum Laude (With high honors) <br><br>
 2.50 – Cum Laude (With honors) <br><br>
3. No grade of 4.0 (conditional) in any subject. <br><br>
4. NSTP grade is not included in the computation of GPA. <br><br>
5. The candidates should be able to complete all the academic requirements (including thesis) 
within the prescribed period of the program. The residency years should e 4, 5 and 6 y ears for a
4-, 5- and 6- year courses, respectively. <br><br>
Failure to finish within the residency period with the following reasons and justification can be
considered: <br><br>
(a) Health Reasons – submit medical certificate duly certified by the University
Physician <br>
(b) Working Students – submit employment record duly certified by HRMO<br>
(c) Force majeure (Acts of GOD) – for unfinished thesis due to fire, typhoon and
uncontrollable circumstances, submit report duly certified by the adviser and the
College Dean. <br>
6. For transferees (school or course/degree), all grades obtained from previous school or form
another course/degree/s will be evaluated. To be eligible to graduate with honors, transferees
should have taken 75% of their required number of units in this university. Grades of 5, 4, and
grades of 2.0, 2.25, and 2.5 for summa, magna and cum laude, respectively, from previous
school/college/degree will make the student ineligible for honors. <br><br>
All units earned in other colleges or universities shall be evaluated on the basis of the following
“table of conversion”.
<br><br>


<table class="table table-striped">
    <tr>
        <th>Grade</th>
        <th>Grade</th>
        <th>Equivalent</th>
    </tr>
    <tr>
        <td>1.00</td>
        <td>95%</td>
        <td>1+ orA+</td>
    </tr>
    <tr>
        <td>1.25 </td>
        <td>93%</td>
        <td>1 or A</td>
    </tr>
    <tr>
        <td>1.50</td>
        <td>90%</td>
        <td>1- or A-</td>
    </tr>
    <tr>
        <td>1.75</td>
        <td>89%</td>
        <td>2+ or B+</td>
    </tr>
    <tr>
        <td>2</td>
        <td>85%</td>
        <td>2 or B</td>
    </tr>
    <tr>
        <td>2.25</td>
        <td>83%</td>
        <td>2- or B-</td>
    </tr>
    <tr>
        <td>2.50</td>
        <td>80%</td>
        <td>3+ or C+</td>
    </tr>
    <tr>
        <td>2.75</td>
        <td>78%</td>
        <td>3 or C</td>
    </tr>
    <tr>
        <td>3.00</td>
        <td>75%</td>
        <td>3- or C-</td>
    </tr>
</table>

7. Non-degree students graduating with GPA of “1.75” and above with no grade lower than 3.0
on all courses (including NSTP) shall be accorded “With Distinction.” <br><br>

8. In all cases, the character, conduct, integrity and reputation of the candidate must be beyond
reproach. <br><br>

In the computation of GPA for graduating students with honors, only two (2) decimal places
shall be used. <br><br>

<b>q) Enrollment for Residency.</b> A student who registered the required six (6) units for thesis or its
equivalent shall enroll another one unit, if he fails to defend his research. However, he has only be
required to enroll residence status if he has successfully defended his research but failed to submit the
bound manuscript and other requirements for graduation. Enrollment for residency shall be made
during the scheduled registration period. <br><br>

<b>r) Time Limit Rule.</b> Degree students shall be required to finish their studies within, at most, two (2) years
beyond the prescribed number of years in their respective curricula while non-degree students shall be
required to finish their certificate/diplomas with, at most, one (1) year. <br><br>

A student who is unable to finish his degree/diploma/certificate within the time limit period
shall be advised to transfer to the jurisdiction of the University Open Learning College offering similar
program. <br><br>

Students returning to enroll in CvSU after a prolonged period and whose prolonged absence was
not due to poor scholarship should seek the endorsement to the University Registrar by the Readmission
Committee. <br><br>

<b>s) Evening and Saturday Classes</b><br><br>

<b>1. Coverage</b><br><br>

Evening and Saturday classes will be offered to non-degree programs. Likewise,
petitioned and/or requested courses of graduating and/or irregular students in the degree
programs may also be offered if teachers concerned are not available during the regular time. <br><br>

<b>2. Enrollment</b><br><br>

Students in evening and Saturday classes are also considered regular students. They
shall follow regular enrollment procedure the same time, place as schedule by the Office of the
Registrar. <br><br>

<b>3. Schedule of Classes</b><br><br>

Evening classes will start at four o’clock in the afternoon and end at nine o’clock in the
evening during weekdays. Saturday classes however, will start at seven o’clock in the morning
and end at nine o’clock in the evening. A separate Bundy card will be used for the purpose. <br><br>

4. Assignment of Faculty<br><br>

All faculty members assigned to teach evening and Saturday classes will be paid
corresponding honoraria will be given to faculty members with full teaching load*
during the regular hour of work. Faculty members who do not satisfy the regular
teaching load without honoraria. A faculty member may only be allowed to handle at
most two lecture classes and one laboratory class everyday. <br>
Non-academic personnel may also be given teaching load if their services are
needed. They will be paid corresponding honoraria at the same rates as the faculty if
their teaching loads are beyond office hours or during Saturdays. <br>
All teaching personnel regardless of rank, designation and class size shall be
entitled to an hourly rate prescribed by the BOR subject to the availability of honoraria
fund. <br><br>

<b><u>Section 3. Policies and Guidelines for the Graduate and distance education Programs.</u></b><br><br>

The following policies apply to both the master’s and doctorate degree program and post
baccalaureate courses offered by the University. The academic programs of the Open Learning College
(OLC) shall also follow these policies and guidelines, unless otherwise specified. <br><br>

<b>a) Admission.</b> Prospective graduate student shall apply for admission to the Graduate SchoolOpen Learning College (GS-OLC) not later than the end of May for the first semester
enrollment (June) and the end of October for the second semester enrollment (November).
Applicants seeking admission to the master’s degree programs must be holders of
bachelor’s degree and with a GPA of at least 2.5. Those seeking admission to the doctorate
degree programs must be holders of master’s degree and with a GPA of at least 1.5. An
applicant for a degree program different from his previous field of specialization shall be
required by the Screening Committee to take recommended preparatory course during the
first semester of residence. <br><br>

The admission of an applicant shall be determined upon submission of the following: <br><br>

1. Duly accomplished application form for admission and three (3) copies of passport size
picture; <br>
2. Original or authenticated official transcript of records bearing the official seal(s) of the
school(s) attended; <br>
3. Two sealed letters of recommendation from a former professor and the immediate
supervisor. These may be personally delivered or mailed to the GS-OLC; <br>
4. Non-refundable application fee f P100.00 for Filipino citizens or US$50.00 for foreign
nationals.(Figures may be changed without prior notice); <br>
5. Approved permit to study (for employed teachers under DepEd and for CvSU
faculty/staff only); <br>
6. Photocopies of students visa and passport (for foreign nationals only); and<br>
7. Certificate of English Proficiency from the Department of Languages and Mass
Communication (DLMC), College of Arts and Sciences (CAS). In addition, students
coming from countries where English is not the medium of instruction must submit a
certification of having obtained a passing score of at least 500 in TOEFL. <br><br>

The application shall personally submit the aforementioned requirements (1, 2, 4-6)
to GS-OLC to enable him to immediately take the written examination needed to satisfy the
requirements in Number 7 above. <br><br>

The GS-OLC and the department concerned reserve the right to require additional
documents/information from an applicant when deemed necessary. All documents shall
become part of the permanent records of CvSU GS-OLC and shall not be returned to
applicants. <br><br>

<b>1. Admission Status.</b> An applicant to a graduate program may be admitted on either <b>regular</b> or
<b>probationary status.</b> Regular status is given to an applicant whose academic records and
supporting documents indicate that he is qualified to undertake graduate study in his chosen
field. Probationary status is given to an applicant whose academic records and supporting
documents indicate deficiencies but show potential for success in graduate studies. <br>
<b>2. Screening Committee.</b> A screening committee created by the Department Chair person shall be
composed of three (3) graduate faculty members from the respective department offering the
graduate program. The Department concerned shall formulate its own screening procedure and
criteria. All documents pertaining to request for admission shall forwarded to the Committee for
evaluation and recommendation. The decision of the Committee shall be forwarded to the
Dean, GS-OLC, who, in turn, informs the applicant of the status of his admission. <br>
<b>3. Notice of Admission.</b> Notice of admission shall be issued by the GS-OLC to qualified beginning
the first week of March for the first semester enrollment and first week of August for the second
semester enrollment. Qualified applicants are required to undergo to medical and dental
examinations administered in the University Infirmary before registration. Students from the
Learning Centers (LC) may have their medical/dental examinations by the government –
accredited physicians. <br>
<b>4. Deferment of Registration.</b> Deferment of registration shall be granted upon written request to
the Dean of GS-OLC for a maximum upon written request to the Dean of GS-OLC for a maximum
of one (1) school year only. Students unable to register after a year shall apply for readmission
following the same admission procedures specified in section 3a above. <br>
<b>5. Change of Status.</b> A student with probationary status may be granted regular status upon
completion of at least six (6) units credited towards a master’s/diploma program and nine (9)
units for doctorate program with a GPA of 2.00 or better. The change of status must be
recommended by the GS-OLC Registrar and approved by the Dean of the GS-OLC.
The secretary of GS-OLC shall notify the graduate student of his academic status
immediately after completing the required number of units. A student who fails to
comply with the above requirement shall be informed that he is qualified from the
intended program of study. <br><br>
<b>6. a) Readmission.</b> All former students who failed to register for more than a year without leave of
absence shall be required to apply for readmission to the GS0OLC. <br><br>
<b>b) Registration.</b> Before a student can register, he must present the Notice of Admission and
the Medical Certificate to the GS-OLC Registrar. Likewise, a student shall confer with his
Registration Adviser concerning the subjects to be registered. <br>
1. Registration of OLC students shall be done in their respective learning centers during the
registration period set by the university. Registration of regular graduate students shall be
done in main campus. <br>
2. Before registration, a faculty member, officially recommended by the Department Chair and
approved by the GS-OLC Dean, shall serve as the ad interim registration adviser until the
students Advisory Committee shall have been officially formed. <br><br>
<b>c) Cross Registration.</b> A CvSU graduate student planning to cross-register courses with other
institution should secure a written permit from the GS-OLC Registrar. Permit may be
granted provided the subjects to be cross-enrolled are not offered by GS-OLC during the
term. Cross-registered subjects shall be subject to validation to cross-register a maximum of
six (6) units. <br><br>
A cross registrant from another educational institution should present a written
permission from his school registrar to the GS-OLC Registrar. The permit should state
the subject(s) and the total number of units the student is allowed to cross-enroll and
that the University shall be the venue for the course(s) to be registered.
For courses with the pre-requisite, the cross registrant shall be required to
present an authenticated proof of equivalency of course(s) and the description(s) of the
required course(s). <br><br>
<b>d) Advisory Committee.</b> A graduate students, in consultation with his ad interim Adviser
and/or the Chairperson of the department where he intends to pursue the graduate
program, selects his Adviser who shall serve as Chairman of the Advisory Committee. <br><br>
The graduate student shall nominate the Advisory Committee not later than two
months after his first registration. The Committee shall be composed of three (3)
members for the master’s degree/diploma course and four (4) for the doctorate degree. <br>
1. For master’s degree students, two (2) members of the Advisory Committee must come from the
department of the student’s major field and one (1) from the cognate field. In the case of post
baccalaureate diploma, three (3) faculty members from the selected major field/department
shall compose the Advisory Committee. <br>
2. For doctorate degree students, three (3) of the committee members should come from his
major department and one (1) from his cognate field. <br>
3. Membership in the Advisory Committee for doctorate degree programs shall be limited to
graduate faculty members who are doctorate degree holders. Advisory Committee for
MS/MA/MAgr/MPS/Diploma shall be holders of at least master’s degree. Affiliate professors in
the Learning Centers may serve as members of the Advisory Committee. <br>
4. The Dean of the GS-OLC shall approve changes in the composition of the Advisory Committee
upon the recommendation of the Department Chairperson with the concurrence of the old and
new member(s) of the committee. <br><br>
<b>e) Plan of Course Work.</b> Before the end of the first semester, a regular graduate student in a
master’s degree program or in a post baccalaureate diploma course shall prepare a plan of course
work in consultation with his Advisory Committee and in accordance with the requirements of the
selected degree program and the GS-OLC. A student on probationary status shall prepare and work
for the approval of his plan of course work immediately after the change of status from
probationary to regular. <br><br>
In the case of doctorate degree students, the plan of course the Plan of Course Work shall be
prepared after passing the qualifying examination. <br><br>
An approved composition of the Advisory Committee and the Plan of Course Work shall be the
requirements for a regular student’s registration for the succeeding semester. <br><br>
Any change in the plan of course work must be recommended by the members of the Advisory
Committee, the Department Chair and approved by the Dean. <br><br>
<b>f) Course Work Requirements.</b> For a master’s degree with thesis, a minimum of 36 units of curse of
work and six(6) units of thesis are required, while for non-thesis a minimum of 42 units of course
work are required. For a doctorate degree, a minimum of 48 units of course work and 12 units of
dissertation are required. <br><br>
Students enrolled in a post baccalaureate diploma course are required to take a minimum of 45
units of course work. <br><br>
Graduate students are also required to take six (6) units of non-credit computer courses except
those who have already taken the prescribed computer courses prior to their admission to GS-OLC,
subject to validation of the Department of Computer Studies, College of Engineering and
information Technology. <br><br>
A graduate student registered for a non-credit course must complete all the requirements of the
course as if these were taken for credit for which he must receive a passing grade of 2.0 or better.
The non-credit courses are assessed on a full-fee basis. <br><br>
<b>g) Unit Load.</b> A non-working student may enroll a maximum load of 12 credit units if classes are
conducted during regular days. However, for Saturdays/summer classes, a graduate student may enroll
a maximum load of nine (9) units for non-laboratory subjects and six (6) units for subjects with
laboratory. CvSU full-time faculty members and staff who are admitted in the GS-OLC shall be allowed to
enroll a maximum of six (6) units per semester. <br><br>
<b>h) Advanced or Transfer Credits.</b> A student may apply to the GS-OLC for transfer credits of academic
work done in another institution only upon the recommendation of the department where he is
planning to specialize, subject to the following conditions:
1. Presentation of credentials showing that he passed the courses registered in another institution
equivalent to those offered in the College or Department from which credit sought; <br><br>
2. Subjects for consideration have not been credited for another degree; and<br><br>
3. Passing the validating examination administered by the Department concerned. <br><br>
Validating examinations shall be administered by the Department concerned during the first
year of the student’s residence. Results of the validating examination shall be submitted to GS-OLC not
later than one week after the date of examination. <br><br>
A maximum of (9) advanced or transfer credit units may be granted to a graduate student
towards a graduate degree. <br><br>
<b>i) Admission in Fields of Specialization.</b> For students to be admitted in a particular major field, a
minimum of five (5) enrollees is required. Otherwise, they shall be encouraged to select a more popular
area of specialization. <br><br>
<b>j) Changing and/or Adding of Subjects.</b> A graduate student may apply for changing/adding of course(s)
within one week after the opening of classes. Changing and/or adding of subjects shall be done for valid
reasons only, with consent of his professor(s), recommended by the adviser, and approved by the Dean
of the GS-OLC. <br><br>
<b>k) Dropping of Subjects.</b> Dropping of subjects is not allowed after three-fourths of the numbers of hours
prescribed for the term has elapsed except for illness and other justifiable reasons such as transfer of
residence elsewhere, locally or abroad. Beyond this period, a student shall be given a failing mark if his
performance is below average or a numerical passing grade if the performance is a satisfactory. <br><br>
A student who intends to drop a course should accomplish an official droppin form to be noted
by the Professor concerned, the Adviser, the Department Chair, and approved by the Dean of the GSOLC. Dropping of courses shall be considered official only upon approval of the Dean of the GS-OLC. <br><br>
<b>l) Attendance.</b> A graduate student shall be automatically dropped from the course when his absences
reached 20 per cent of the total number of hours required for the course. If majority of these absences
are not excused and the student’s performance in unsatisfactory he shall be given a grade 5.0 in the
course. The professor shall report the case officially in writing to the Dean of the GS-OLC. Time lost due
to late enrollment shall be considered as absence from classes. <br><br>
<b>m) Residence Requirement and Time-limit Rule.</b> A minimum of four (4) semesters and one (1) summer
of residence is required for a master’s degree or a post baccalaureate diploma course. For a doctorate
degree, a minimum of six (6) semesters and one summer is required. A student is in residence when he
is registered for a course work with the approval of his Advisory committee. <br><br>
Work in absentia may be granted if a student will be conducting and/or writing the manuscript
of his thesis/dissertation with the approval of his Advisory Committee. In such a case, the students must
duly registered in thesis/dissertation. A graduate student who works in absentia must submit periodic
progress reports to the chairman of his Advisory Committee. <br><br>
The maximum period for completing a master’s degree or a post baccalaureate diploma course
shall be five (5) years, and seven (7) years for the doctorate degree. The counting of years starts from
the time of initial enrollment in the program, inclusive of the Leave of Absence. A graduate student who
fails to complete the requirements for the program that he is pursuing within the time limit will be
disqualified from the program but may apply for readmission to the Graduate School-open learning
College in another Program (degree program or major field). <br><br>
Graduate students under the distance education program of the Open Learning College shall be
subjected to the following time-limit rule: <br><br>
A student should be able to finish all courses in the: <br><br>
1. Master’s level/post baccalaureate diploma in not more than seven (7) years. <br>
2. Doctorate level in not more than nine (9) years. <br><br>
<b>n) Leave of Absence.</b> A students request for leave of absence must be approved by the Dean of the GSOLC upon endorsement by the Chairman of Advisory Committee and noted by the Department
Chairperson. The request should state the reason(s) for which the leave is requested. An approval leave
of absence shall be counted toward the time limit. <br><br>
A graduate student with leave of absence exceeding two (2) years or stop attending classes for
two years or more without approval leave of absence but within the time limit rules shall be readmitting
in the same program only after passing the validating examinations in all subjects taken. <br><br>
o) Honorable Dismissal. A graduate student who desires to sever connection with the University shall
submit a written petition to the University Registrar, noted by the Dean of the GS-OLC. If the request is
granted, the student shall be given “Honorable Dismissal” by the University Registrar. <br><br>
A clearance from the University must be secured before a certificate of honorable dismissal is
issued. No certification of “Honorable dismissal” shall be granted to a graduate student with pending
case(s) of violation of University rules and regulation. <br><br>
Honorably dismissed students may get a certification of grades for all the courses taken from
the GS-OLC Registrar and noted by the Dean of GS-OLC. <br><br>
<b>p) Grade Requirements and Retention.</b> In order ti qualify for the general comprehensive examination, a
student must obtain a GPA of 2.00 or better for all courses taken. Courses listed under “others” shall be
excluded from the computation but grades in these subjects must be passing. <br><br>
Failure to pass a subject twice shall disqualify the student from the graduate program. <br><br>
Similarly, a graduate student must maintain a GPA of 2.00 or better every term in order to
qualify to continue with his program. <br><br>
<b> q) Grades and Grading System.</b> The University shall adopt the numerical grading system of “1.00” to
“5.00”, where “1.00” is the highest grade and “5.00” is a failing grade. The system of grading is as
follows: <br><br>
1.00 --------------------Excellent<br><br>
1.25<br><br>
1.50 --------------------Very Good<br><br>
1.75<br><br>
2.00 ------------------ Good<br><br>
2.25<br><br>
2.50<br><br>
2.75<br><br>
3.00 ------------------Passed<br><br>
4.00 ------------------Conditioned<br><br>
5.00 --------------------Failed<br><br>
Inc. -----------------------Incomplete<br><br>
S Satisfactory, meets the expected outputs for thesis/dissertation<br><br>
U Unsatisfactory, does not meet the expected output for thesis/dissertation<br><br><br>
A grade of “Inc.” is given to a student with passing class standing but fails to complete other
course requirements. Removal of “Inc.” grade must be done by meeting all the requirements for the
course within one year immediately following the term in which the grade “Inc.” was incurred. If a
student fails to remove the “Inc.” grade within one (1) year, he shall automatically be given a grade of
“5.00” in the subject. <br><br>
A student, who incurred an incomplete grade under a professor who has gone abroad for more
than six (6) months or who has transferred or resigned, may complete his “Inc.” grade under another
professor of the same subject. <br><br>
<b>r) Changing of Degree Program/Major and Mino Fields.</b> A student who plans to change his graduate
program should apply to the GS-OLC. Credentials of the applicants shall be forwarded to the Screening
Committee of the department where he is planning to take his new graduate program. A change in a
student’s major/minor/cognate fields must be endorsed by his Adviser and the Chair of the Department
where the student plans to take his new major/minor/cognate field and approved by the Dean. <br><br>
<b>s) Qualifying Examination.</b> Only regular doctorate degree students shall be allowed to take the written
qualifying examination after earning nine units of the required courses. The examination shall be
administered by the Advisory Committee. The result of the examination shall be the basis for evaluating
the student’s ability to purse the doctorate degree and for determining a suitable program of course
work for him. <br><br>
The student shall submit his application for the qualifying examination to the Dean, GS-OLC, not
later than one (1) month before the date of the examination. The application must be duly
recommended by the Advisory Committee and noted by the Chair of the student’s major Department.
Details of the qualifying examination shall be left to the discretion of the Advisory Committee. <br><br>
To pass the examination, the student must obtain a unanimous “passing” vote from the
members of the Committee. <br><br>
The Chairman of the Advisory Committee shall submit to the Dean a report on the result of the
examination within one (1) week after the examination. <br><br>
If the student fails the qualifying examination, an oral examination within one week after the
first examination may be allowed subject to the unanimous approval of the Advisory Committee. If the
student fails in the re-examination, he shall be permanently disqualified from the program. <br><br>
<b>t) General Comprehensive Examination.</b> A graduate student who has completed all the academic
requirements prescribed in his approved plan of course work shall apply for a written department
comprehensive examination. Application for comprehensive examination shall be submitted for
approval to the Dean, GS-OLC, not later than one month before the date of examination. This shall be
endorsed by the Advisory Committee and recommended by the Department Chairperson. <br><br>
The respective Department shall administer written and oral comprehensive examinations. A
written examination shall be given for each area (Core, Major, Cognate courses) indicate in the graduate
student’s plan of course of work. A student must pass the examination in each of the three areas. <br><br>
The Chairperson of the Department shall submit to the Dean of the GS-OLC a report on the
result of the written examination two (2) weeks after the examination. <br><br>
A student shall be allowed to take the written comprehensive examination in all or any three (3)
areas only twice. The c=second examination must be taken and passed within one (1) year after the first
examination. <br><br>
Oral examination shall be given after the passing the written examination. The details of the
examination shall be left to the discretion of the Advisory Committee and an external expert. A
unanimous “passing” vote of the members of the Committee is required in order to pass the oral
examination. <br><br>
<b>u) Thesis/Dissertation.</b> A graduate student is ready to conduct his thesis/dissertation if the following
requirements are satisfied: <br><br>
1. Passed the general comprehensive examinations; and<br><br>
2. A thesis/dissertation outline following the University prescribed format is approved and
recommended by the Advisory Committee after oral deliberations. The outline shall be endorsed by the
Department Chair, noted by the Director for Research, and submitted to the Dean of the OGS-OLC.
Copies of the approved outline shall be distributed to the members of the Advisory Committee and the
Dean of the OGS-OLC. <br><br>

Graduates students enrolled in the doctorate degree or master’s degree dissertations/thesis are
expected to produce the following output in accordance with the number of units enrolled: <br><br>

<table class="table table-striped">
    <tr>
        <th>Units Enrolled
            <table class="table">
                <tr>
                    <th>Master’s</th>
                    <th>Doctorate</th>
                </tr>
            </table>
        </th>
        <th>Expected Output</th>
    </tr>

    <tr>
        <td>
            <table class="table">
                <tr>
                    <td>1</td>
                    <td>1-2</td>
                </tr>
            </table>
        </td>
        <td>Approved thesis/dissertation outline</td>    
    </tr>

    <tr>
        <td>
            <table class="table">
                <tr>
                    <td>2</td>
                    <td>3-5</td>
                </tr>
            </table>
        </td>
        <td>Gathered data/conducted experiment</td>    
    </tr>

    <tr>
        <td>
            <table class="table">
                <tr>
                    <td>3</td>
                    <td>6-8</td>
                </tr>
            </table>
        </td>
        <td>Analyzed and interpreted data</td>    
    </tr>

    <tr>
        <td>
            <table class="table">
                <tr>
                    <td>4</td>
                    <td>9-10</td>
                </tr>
            </table>
        </td>
        <td>Prepared 1st draft of the manuscript</td>    
    </tr>
    <tr>
        <td>
            <table class="table">
                <tr>
                    <td>5-6</td>
                    <td>11-12 manuscript</td>
                </tr>
            </table>
        </td>
        <td>Passed final examination/reproduced final </td>    
    </tr>   
</table>

<b>v) Final Examination.</b> A panel of Examiners shall administer the final oral examination on a graduate
student’s thesis/dissertation. The student’s application for final examination, duly recommended by the
Advisory Committee and noted by the Department of Chair, shall be submitted for approval to the Dean
of the GS-OLC not late than two (2) weeks before the actual date of the examination. The student must
be enrolled in his thesis/dissertation during the term at which the final examination takes place. Final
examinations shall be conducted at the main campus. <br><br>
The candidate must provide a copy of the final draft of the thesis/dissertation manuscript to
each the members of the Panel of Examiners at least two (2) weeks before the date of the final
examination. <br><br>
The chairman of the panel of examiners shall submit on a prescribed form a report on the result
of the first examination upon re-application to the GS-OLC within three (3) days after the final
examination. <br><br>
A student who fails the examination may be given a re-examination within one month after the
first examination upon re-application to the GS-OLC, as recommended by the Advisory Committee,
noted by the Department Chair and approved by the GS-OLC. Failure to pass the second examination
disqualifies the student from earning the degree. <br><br>
<b>Panel of Examiners.</b> The Chairman and the members of the Panel of Examiners shall be chosen
on the basis of their expertise and area of specialization. The Department Chairperson shall appoint the
Chairman and the members of the panel. <br><br>
The Panel shall include one external expert as member and two graduate faculty members. <br><br>
The GS-OLC Research Coordinator and the Chairman of the Advisory Committee shall sit in the
oral defense but will not give grades to the student/<br><br>
The external expert, whose area of expertise is on the major field of study of the graduate
student, shall come from the firms and other institution outside of the University. <br><br>
<b>w) Fees and Financial Assistance.</b> The charges to be borne by the CvSU GS-OLC students include tuition
and other fees. These may be reduced through financial assistance programs in the form of fellowship,
scholarship and other grants. <br><br>

1. Charges for Graduate School –Open Learning College*

<table class="table table-striped">
    <tr>
        <td>Tuition</td>
        <td>P275.00/unit</td>
    </tr>
</table>

Laboratory Fee:
<table class="table table-striped">
    <tr>
        <td>Science</td>
        <td>200.00/subject</td>
    </tr>
    <tr>
        <td>Computer</td>
        <td>400.00/subject</td>
    </tr>
    <tr>
        <td>SFDF</td>
        <td>1500</td>
    </tr>
    <tr>
        <td>SRF</td>
        <td>1850</td>
    </tr>
    <tr>
        <td>Thesis/Dissertation Fee</td>
        <td>670.00/unit</td>
    </tr>
</table>
<br>
Miscellaneous Fees: <br>
Service Fees:
<table class="table table-striped">
    <tr>
        <td>Library</td>
        <td>250</td>
    </tr>
    <tr>
        <td>Medical</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Dental</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Registration</td>
        <td>50  </td>
    </tr>
    <tr>
        <td>Application</td>
        <td>100.00/50.00</td>
    </tr>
    <tr>
        <td>Publication</td>
        <td>60</td>
    </tr>
</table>
<br>
Other Fees:
<table class="table table-striped">
    <tr>
        <td>Deferment</td>
        <td></td>
    </tr>
    <tr>
        <td>Filipino student </td>
        <td>100</td>
    </tr>
    <tr>
        <td>Foreign student</td>
        <td>$10.00</td>
    </tr>
    <tr>
        <td>Late Registration(fine) </td>
        <td>100.00  </td>
    </tr>
    <tr>
        <td>Change of Program</td>
        <td>50.00</td>
    </tr>
    <tr>
        <td>Dropping of Course</td>
        <td>100.00/subject</td>
    </tr>
    <tr>
        <td>Leave of Absence</td>
        <td>100</td>
    </tr>
    <tr>
        <td>Validation</td>
        <td>100.00/subject</td>
    </tr>
    <tr>
        <td>ID Card </td>
        <td>50.00</td>
    </tr>
    <tr>
        <td>True Copy of Grades </td>
        <td>50.00</td>
    </tr>
    <tr>
        <td>Residence   </td>
        <td>275.00/semester </td>
    </tr>
    <tr>
        <td>Qualifying Examination Fee</td>
        <td>100</td>
    </tr>
</table>
<br>
Comprehensive Examination Fee:
<table class="table table-striped">
    <tr>
        <th>Oral</th>
        <th>Written</th>
    </tr>
    <tr>
        <td>2,700.00(for master’s/diploma) and 3,400.00 (for doctorate)</td>
        <td>2,700.00(for master’s/diploma) and 3,400.00(for doctorate)</td>
    </tr>
</table>
<br>
Final Defense Fee:
<table class="table table-striped">
    <tr>
        <td>2,000.00(for master’s) (30% for adviser, 30% for panel member, 20% for Research Coordinator)</td>
        <td>2,600.00 (for doctorate) (26% for adviser, 26% for panel chair, 16% for each panel member, 16% for Research Coordinator)</td>
    </tr>
</table>
<br>
Extramural Study Program Fee - 1,500.00 (This will be managed and disbursed by GS-OLC) <br>
Distance Education Program Fee - Distance Education Program Fee
<br><br>
All fees (except those under “Other Fees”) shall be paid upon enrollment. In case of partial
payment, only the Students Facilities Development Fund (SFDF) should be that remaining balance to be
paid before the mid-term examination. <br><br>
<b>Thesis/Dissertation Fees.</b> The thesis/dissertation fees shall be managed and disbursed by the
Administration. These fees shall be given to the Advisory Committee during every term the
thesis/dissertation is enrolled by student provided a grade is submitted. <br><br>
<b>2. Refund of Fees.</b> A student who withdraws within one month after the date of registration shall be
refunded 50% of the total amount paid. No refund shall be made if a graduate student withdraws after
the start of regular classes. <br><br>
<b>3. Financial Assistance.</b> A graduate student may avail of the following financial assistance: <br><br>
<b>3.1 Study Privileges for CvSU Personnel.</b> All full-time university personnel shall be entitled to
100% waiver of tuition and services fees. This applies to full-time personnel-permanent,
temporary casual (with at least one year of continuous service in the University ) provided that
their appointments issued by the University are at least within the semester or term, provided
further that permit to enroll the choses course has been granted by the office of the University
President. <br><br>
<b>3.2 Graduate Fellowship/Scholarship.</b> The CvSU Graduate Fellowship/Scholarship shall be open
to faculty members and employees of CvSU, ACAP, PASUC member institutions and other
government agencies. <br><br>
A graduate fellow/scholar shall register on full-time basis and take a maximum load of twelve
(12) units per semester and nine (9) units during summer. He shall maintain a GPA of GPA of 1.50 or
better every term. Fellowship/scholarship grantees shall enjoy free tuition, monthly stipend, book
allowance and thesis/dissertation support. A graduate fellow shall be required to work as teacher or
researcher in the University 20 hours a week during the time of his scholarship. <br><br>
The number of fellows/scholars shall be determined on the basis of the needs of the University
and the availability of funds. <br><br>
<b>x) Graduate Faculty.</b><br><br>
<b>1) Qualifications.</b> Qualification criteria for regular an affiliate include: <br><br>
1.1 A regular graduate faculty member must have a master’s degree or its equivalent to
qualify to teach in the master’s degree program, and a doctorate degree program. His
degree must have been earned from a reputable institution recognized in that
discipline. <br><br>
1.2 Non-academic personnel with master’s/doctorate degree and have work experience
in the required fields of specialization may be included in the pool of Graduate Faculty
as affiliates. <br><br>
1.3 A thesis Adviser must have at least a master’s degree or its equivalent obtained from
a reputable institution recognized in that discipline. He must be the author of at least
two technical articles other than his master’s thesis published in a scientific journal. <br><br>
1.4 A dissertation Adviser must have a doctorate degree or its equivalent obtained from
a reputable institution recognized in that discipline. He must have been a thesis adviser
at least one Ms/MA graduate. He must be the author of at least two technical articles
other than his doctorate dissertation published in a scientific journal. <br><br>
1.5 A graduate faculty member can act as thesis/dissertation Adviser to a maximum of
five (5) graduates students at any one time except in cases where there is limited
number of available/ qualified graduate faculty. <br><br>
<b>2) Faculty workload.</b> A faculty member shall be given academic load(s) based on his field of
specialization. At least three (3) professors for each subject shall be identified and prioritized to
teach a particular subject. <br><br>
During Saturdays a graduate faculty member shall handle a maximum load of six (6)
units of non-laboratory courses or three (3) units of laboratory courses [equivalent to five (5)
hours teaching load. <br><br>
<b>y) Extramural Study Program (ESP)/Distance Education Program (DEP)</b><br><br>
<b>1. Learning Centers.</b> A Learning Center ( LC) for the GS Extramural Study Program and the OLC
Distance Education Program shall be established and implemented following these guidelines. <br><br>
1.1 An ESP/DEp Learning Center must be at least 20-kilometer radius away from the
main campus and its operation shall be covered by a memorandum of Agreement
between the University and the Learning Center, except for LC’s located at the
branch/satellite campuses of the University; <br>
1.2 Facilities and other resources needed in the conduct of ESp/DEP must be available in
the Learning Center; <br>
1.3 An LC Coordinators shall be selected for each Learning Center. In the case of the
satellite and branch campuses, the Campus Deans shall act as the LC Coordinator; <br>
1.4 The ESP Learning Center must show potential for a sustainable program in the terms
of the number of possible clients; <br>
1.5 ESP courses shall be offered only upon request of at least 15 prospective students.
New enrollees shall be accommodated only during the first semester. For DEP courses,
students may enroll anytime regardless of the academic term; <br>
1.6 Only master’s and diploma programs shall be offered under the ESP at the Learning
Centers; <br>
1.7 ESP classes in the learning centers shall be conducted on Saturdays during regular
semester’s and on weekdays during summer; and<br>
1.8 Student in the Lc must take at least 25 per cent of their academic courses in the
Main campus except for students OLC. <br>
<b>2. Supervision of ESp/DEP.</b> The Extramural Study Program and the Distance Education program
shall be supervised by designated Program Directors. <br><br>
<b>3. Additional implementing Guidelines for the Distance Education Program.</b><br><br>
3.1 OLC shall offer the following courses through the DEP: <br><br>
3.1.1 Non-laboratory General Education, major, and minor courses in the nondegree, undergraduate and graduate programs offered by the University<br><br>
3.1.2 ETEEAP non-laboratory courses<br><br>
3.2 A maximum of 18 units or 6 subjects for undergraduate courses, and 9 units
or 3 subjects for graduate courses may be enrolled by a student during a regular
semester, and 6 units or 2 subjects for courses in any level during summer. <br><br>
3.3 Lessons and instructions shall be disseminated among student through
learning modules and/or electronic-based learning materials. These modules
may be initially distributed in CDs and later uploaded in the internet. <br><br>
3.4 A student enrolled in a subject who utilized the modular approach shall be
required to report to the learning center nearest his residence at least four
times during a term for further/additional instructions and/or written
examinations. <br><br>
3.5 All students shall be required to take at least four long examinations in each
subject enrolled during a term. <br><br>
3.6 A student’s final grade shall be based upon his submitted reports, projects,
exercises, assignments and four or more long examinations. <br><br>
<b>z) Graduation.</b> A graduate student who is a candidate for graduation shall furnish the GS-OLC an
abstract of his thesis/dissertation at least one week before the University Academic Council meeting to
decide graduation of students. <br><br>
Nine (9) properly bound copies of the manuscript must be submitted to the GS-OLC not later
than the following deadlines: <br><br>
1.<b> For Summer Graduates</b> – the day before the first day of regular registration for the succeeding
first semester<br>
2. <b> For First Semester Graduates</b> – the day before the first day of regular registration for the
succeeding second semesters<br>
3.<b> For Second Semester Graduates</b> – the day before the Academic council meeting to decide
graduation of students. <br><br>
A student who has completed all the academic requirements for a degree and other
requirements including clearance forms and graduation fees shall be included in the list of graduating
students. Candidates for graduation are required to attend the commencement exercise. Those who
cannot attend because of valid reasons such as illness or a scheduled travel abroad must submit a
request for graduation in absentia of the Dean of GS-OLC. <br><br>
The following awards shall be given to deserving graduates: <br><br>
1. <b>University State Award.</b> This shall be awarded to a graduate with GPA of 1.25 or better; <br>
2. <b>College State Award.</b> This shall be given to a graduate with GPA of 1.50 to 1.26; and<br>
3. <b>Best Thesis/Dissertation Award.</b> Recipient (s) of this award shall be determined by a Search
Committee headed by the Research Director. <br><br>
Transcript of records can only be issued upon presentation of valid clearance.



				</div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                 <!-- Modal -->
        <div class="modal fade" id="accre" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Program Accreditation</h5>
                            </div>
                            <div class="modal-body text-justify">

The University shall as much as possible, submit all programs for accreditation particularly by
the Accrediting Agency of Chartered Colleges and Universities in the Philippines (AACCUP) or any
accrediting agency prescribed by CHED and the Philippines Association of State Universities and Colleges
(PASUC) <br> <br>
Relevant to this, the University President shall form a local University-wide accrediting body to
be headed by the Director for Quality Assurance and Accreditation. It is the duty of this body to prepare
for accreditation of programs, including review and inspection of documents (local accreditations) and
schedule accreditations visits.  <br> <br>
The University may tap the services of other accrediting institutions or other outside agencies.
				</div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>


        
        <!-- Modal -->
        <div class="modal fade" id="revi" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Curriculum Revision </h5>
                            </div>
                            <div class="modal-body text-justify">
Introduction of new curricula and revision of the existing ones should follow the requirements
and guidelines by the Commissions on Higher Education (CHED) per Memorandum Letter dated 23 May
2001 follows: <br> <br>
<b> a) Minor Revisions.</b> The following documents and standard process shall be included in agenda
folder during the Board meeting: <br>
1. Resolution of the Academic council recommending approval of the proposed
revision duly certified by the Board Secretary and attested by the President,
attaching the approved curriculum; <br>
2. The rationale, objectives and strategies and processes pursued; <br>
3. Implementation Scheme issued by the President notifying all concerned regarding
the action of the Board; and<br>
4. Other requirements which the Board may prescribe. <br><br>
<b> b) Major Revisions. </b>The guidelines for minor revisions shall likewise apply in any case of major
revisions. <br> <br>
In addition, a Feasibility Study or End-User Survey shall be prepared by the
College/Campus proposing the revision. <br> <br>
Furthermore, a copy of the revised curriculum approved by the Board shall be
furnished to the CHED Regional Office for information and reference purposes. <br> <br>
<b> c) Offering of New Programs.</b> The same guidelines for major and minor revisions shall apply in
considering the offering of new programs. <br> <br>
In addition, the following requirements shall be submitted to the Board during
its deliberation: <br>
1. Proposed curriculum must be in accordance with the Policies and Standards of the program
and the CHED Memo Order No. 59, s 1996, The New General Education Curriculum (GEC); <br>
2. A Feasibility Study should be conducted based on the assessment of community needs and
viability of the program in terms of: demand for the program, prospective students;
excisting schools offering the same course within the province of Cavite. <br>
3. Faculty profile for the program applied for, their educational qualifications, area of
specialization, subject assignment in accordance with their qualifications; employment
status; and teaching experience; <br>
4. List of University Administrators from the University President down to the Department
Heads of the college proposing the course. This shall include their educational qualification,
administrative experience, employments status, etc; <br>
5. List of academic non-teaching personnel such as Registrar, Librarian, guidance Counselor,
Researcher, etc and their educational qualifications, employment status and work
experience; <br>
6. Pictures of all physical facilities, including site and buildings, classrooms, laboratories,
library, medical and dental health, canteens, etc; <br>
7. List of library holdings (to be certified by the President). These holdings should at least be 3,
000 non-fiction accessional titles, and at least 300 professionals titles for each major
program. <br>
8. List of laboratory facilities, equipment, furniture, supplies and materials classified by subject
area; <br> <br>
<b> d) Submission.</b> The Board Resolution approving the offering of the new program(s) together the
above requirements shall be submitted to the CHED Central Office for MIS purposes and to the
CHED Regional Office for information and reference purposes. <br> <br>
<b> e) Forms.</b> The documents and other requirements should conform to the forms provided by CHED
in the above cited Memorandum Letter. <br> <br>
<b>f) Course Number System. </b> In addition to the CHED requirements, the numbers of courses in
revised or proposed program should conform to course number system being adopted by
university. <br> <br>
<b>g) Phase Out Program.</b> A phase-out program should be anticipated in the implementation of new
or revised programs. <br> <br>
If the new program is designed to replace an existing curriculum, the
implementation should start from the incoming freshmen only and the old curriculum
should end with the graduation of the current students taking it. <br> <br>
In the revised courses, the compulsory requirement for students for the
introduced/revised courses should start only in the current year they are supposed to
take course. In no case shall the introduced/revised courses be required as back subjects
for students. <br> <br>
<b>h) Schedule of Revision/Introduction of New Courses.</b> Unless the revision or introduction of new
required course is a mandatory requirement by CHED, no revision on any curriculum og the
University shall be made within five (5) years of its implementation. <br> <br>
				</div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
         <div class="modal fade" id="susp" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Suspension of Classes</h5>
                            </div>
                            <div class="modal-body text-justify">
<b>a) Authority to Suspend Classes.</b> The University President has the final authority to suspend
classes throughout the University including all units or branches, or he may suspend classes in
specific units or campuses for specified periods of time. Suspension of classes does not mean
that faculty and employees will not report for duty. <br> <br>
The suspension, dismissal or postponement of classes in any academic unit by
the dean concerned should have previous authority from the President except in
emergency cases when the dean or campus administrator immediately issues an order
for the suspension of classes after which he shall make a report to the President on the
circumstances which compelled such action. <br><br>

<b>b) Bases of Suspenson of Classes.</b>  Classes are suspended primarily to assure the safety of students upon the advent, usually unexpected calamities, and forces of nature such as typhoons, earthquakes and tsunamis. <br> <br>
With respect to typhoons, classes will be suspended upon advice of Philippine
Atmospheric Geophysical and Astronomical Services Authority (PAG-ASA) whenever the
typhoon is of sufficient intensity to make it advisable to suspend classes in the
elementary grade and moreover when the approach of the typhoon becomes ore
definitely pronounced as to require suspension of classes in the high school and
collegiate levels as well. Aside from such official announcements to be made, classes
may be considered automatically suspended in the elementary grades when reports
throughout the mass media confirm the raising of typhoon Signal No.2, the suspension
to apply furthermore to all high school and collegiate levels if typhoon signal is raised to
Typhoon Signal No. 3. <br> <br>
The University President may likewise automatically suspend classes even if the
typhoon signal is below 3 but is accompanied by unabated torrential rains resulting to
heavy floods and/or landslides. <br> <br>
With respect to earthquakes, those of serious intensity require immediate
suspension of classes to enable an inspection of the building and premises where classes
are being held. A general rule to follow upon announcement of PAG-ASA is that the
intensity of the tremor is at least Intensity V to allow a 24-hour period from time of the
earthquake as the duration of the suspension of classes. <br> <br>
Other force majeure and fortuitous events or circumstances which may compel
immediate suspension of classes are fires, epidemics and bombs threats which will be
dealt with accordingly as the occasion arises. <br> <br>
Classes are also suspended for short periods of time to enable students to
attend University convocations or special gathering. However these are pre-schedules=d
events for which announcement are circulated in advance. <br> <br>
In the absence of the University President, the person next in rank in the
hierarchy of command succession adopted by the University shall decide on the
suspension of classes. <br> <br>
				</div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>



        <!-- Modal -->
        <div class="modal fade" id="gen" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">General Academic Rules and Regulations</h5>
                            </div>
                            <div class="modal-body text-justify">
                            University students are those who are enrolled in and who are regularly attending graduate, 
                            degree, non-degree, high school or any other level program of the University. University students also 
                            include those enrolled at the University distance education program. <br><br>
                            <b>a) A full-time student </b>is one who registered for formal academic credits units and who carries 
                            the full load for a given semester under the curriculum in which he is enrolled including 
                            graduating students who may carry less than the full load for purpose of completing the 
                            requirements of the current semester.<br>
                           <b> b) A part-time student </b>is one who is registered for formal credits but who carries less than full 
                            load for a given semester under the curriculum in which he is enrolled.<br>
                            <b>c) A transfer student </b>is one who comes from another college/university where he started 
                            studying for a course and who is now registered in the University after fulfilling all 
                            requirements as transfer student. Transferees during the last semester of the last year of a 
                            given curriculum shall be discouraged.<br>
                            <b>d) A student assistant</b>is one who is employed on a full-time basis at the University rendering 
                            service of at least 100 hours a month. A student assistant is advised to carry reduced load 
                            for at most 18 units academic load.<br>
                           <b> e) A foreign student </b>is a University student who is not a citizen of the Philippines. In case there 
                            are more than five (5) foreign students, an adviser shall be designated to look after their 
                            welfare. If the number of foreign students is five (5) or less, the Dean of Student Affairs shall 
                            handle advisor ship to these students.<br>
                           <b> f) Curricular classification</b> shall be based on the actual number of academic units completed 
                            as required for a particular curricular year. For this purpose, a student shall be classified as 
                            Freshman, Sophomore, Junior, and Senior depending on the total required academic units 
                            he has earned. The official curricular classification of students shall be responsibility of the 
                            University Registrar.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

        <!-- Modal -->
        <div class="modal fade" id="admin" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Administrators (1906 - Present)</h5>
                            </div>
                            <div class="modal-body text-justify">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th class="fw-bold">YEAR</th>
                                            <th class="fw-bold">NAME</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <tr>
                                            <td>1906-1908</td>
                                            <td>Mr. C.E. Workman</td>
                                        </tr>
                                        <tr>
                                            <td>1908-1911</td>
                                            <td>Mr. Henry Wise</td>
                                        </tr>
                                        <tr>
                                            <td>1911-1915</td>
                                            <td>Mr. Joseph Coconawer</td>
                                        </tr>
                                        <tr>
                                            <td>1919-1930</td>
                                            <td>Mr. Simeon Madlangsakay</td>
                                        </tr>
                                        <tr>
                                            <td>1930-1936</td>
                                            <td>Mr. Basilio O. Viado</td>
                                        </tr>
                                        <tr>
                                            <td>1936-1938</td>
                                            <td>Mr. Camilo Guevara, Sr.</td>
                                        </tr>
                                        <tr>
                                            <td>1938-1940</td>
                                            <td>Mr. Santiago Medrano</td>
                                        </tr>
                                        <tr>
                                            <td>1940-1941</td>
                                            <td>Mr. Jose Crisanto</td>
                                        </tr>
                                        <tr>
                                            <td>1941-1942</td>
                                            <td>Mr. Apolonio Muñoz</td>
                                        </tr>
                                        <tr>
                                            <td>1942-1945</td>
                                            <td>Mr. Simeon Madlangsakay</td>
                                        </tr>
                                        <tr>
                                            <td>1945-1953</td>
                                            <td>Mr. Basilio O. Viado</td>
                                        </tr>
                                        <tr>
                                            <td>1953-1954</td>
                                            <td>Mr. Paulino E. Costa</td>
                                        </tr>
                                        <tr>
                                            <td>1954-1955</td>
                                            <td>Mr. Agripino Constantino</td>
                                        </tr>
                                        <tr>
                                            <td>1955-1956</td>
                                            <td>Mr. Leonardo Pulido
                                                (Teacher-in-Charge)</td>
                                        </tr>
                                        <tr>
                                            <td>1956</td>
                                            <td>Mr. Fortunato A. Mojica</td>
                                        </tr>
                                        <tr>
                                            <td>1956-1957</td>
                                            <td>Mr. Fortunato A. Mojica</td>
                                        </tr>
                                        <tr>
                                            <td>1957-1960</td>
                                            <td>Mr. Mariano Macasaet
                                                (Teacher-in-Charge)</td>
                                        </tr>
                                        <tr>
                                            <td>1965-1975</td>
                                            <td> Mr. Romeo B. Reyes
                                                (Principal)</td>
                                        </tr>
                                        <tr>
                                            <td>1957-1960</td>
                                            <td>Mr. Mariano Macasaet
                                            (Teacher-in-Charge)</td>
                                        </tr>
                                        <tr>
                                            <td>1960-1965</td>
                                            <td>Mr. Vicente G. Hicaro
                                                (Principal-in-Charge)</td>
                                        </tr>
                                        <tr>
                                            <td>1965-1975</td>
                                            <td>Mr. Romeo B. Reyes
                                                (Principal)</td>
                                        </tr>
                                        <tr>
                                            <td>1967-1970</td>
                                            <td>Mr. Santiago Rolle
                                                (Acting President)</td>
                                        </tr>
                                        <tr>
                                            <td>1970-1971</td>
                                            <td>Mr. Vicente T. Pinazo
                                                (President)</td>
                                        </tr>
                                        <tr>
                                            <td>1983-2008</td>
                                            <td>Dr. Ruperto S. Sangalang
                                                (President)</td>
                                        </tr>
                                        <tr>
                                            <td>2008 to present</td>
                                            <td> Dr. Divinia C. Chavez
                                                (President)</td>
                                        </tr>
                                        
                                        

                                    </tbody>
                                </table>
                            
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
        <div class="modal fade" id="gen" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable  modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">General Academic Rules and Regulations</h5>
                            </div>
                            <div class="modal-body text-justify">
                            University students are those who are enrolled in and who are regularly attending graduate, 
                            degree, non-degree, high school or any other level program of the University. University students also 
                            include those enrolled at the University distance education program. <br><br>
                            <b>a) A full-time student </b>is one who registered for formal academic credits units and who carries 
                            the full load for a given semester under the curriculum in which he is enrolled including 
                            graduating students who may carry less than the full load for purpose of completing the 
                            requirements of the current semester.<br>
                           <b> b) A part-time student </b>is one who is registered for formal credits but who carries less than full 
                            load for a given semester under the curriculum in which he is enrolled.<br>
                            <b>c) A transfer student </b>is one who comes from another college/university where he started 
                            studying for a course and who is now registered in the University after fulfilling all 
                            requirements as transfer student. Transferees during the last semester of the last year of a 
                            given curriculum shall be discouraged.<br>
                            <b>d) A student assistant</b>is one who is employed on a full-time basis at the University rendering 
                            service of at least 100 hours a month. A student assistant is advised to carry reduced load 
                            for at most 18 units academic load.<br>
                           <b> e) A foreign student </b>is a University student who is not a citizen of the Philippines. In case there 
                            are more than five (5) foreign students, an adviser shall be designated to look after their 
                            welfare. If the number of foreign students is five (5) or less, the Dean of Student Affairs shall 
                            handle advisor ship to these students.<br>
                           <b> f) Curricular classification</b> shall be based on the actual number of academic units completed 
                            as required for a particular curricular year. For this purpose, a student shall be classified as 
                            Freshman, Sophomore, Junior, and Senior depending on the total required academic units 
                            he has earned. The official curricular classification of students shall be responsibility of the 
                            University Registrar.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>


         <!-- Modal -->
         <div class="modal fade" id="isko" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">University Scholarship</h5>
                            </div>
                            <div class="modal-body text-justify">
                            Scholarship in the university shall be classified into: entrance scholarship, university or full 
                            scholarship, and college or partial scholarship. These scholarships are defined as follows: <br> <br>
                            a) An <b>entrance scholarship*</b> shall consist of free tuition or, in units where no tuition is charged; free laboratory fee shall be enjoyed for one semester only by the following students upon admission to the University. <br><br>

                            Valedictorian, salutatorians and honor students from recognized public/private
                            high schools shall be awarded entrance scholarships. In order to avail this scholarship,
                            valedictorians, salutatorians and honor graduates should come from graduating classes
                            with at least 30 students to be certified by the head of the school concerned; provided
                            further that valedictorians and salutatorians from high school units of the University
                            shall be exempted from taking the university entrance examination and from payment
                            of regular University fees including tuition, except the miscellaneous fees. <br>
                            Entrance scholarship shall be for the first semester only. The renewal to full or
                            partial scholarship shall be subject to terms and conditions of Sections b and c below. <br><br>
                            b) <b> A university or full scholarship</b> which consist of free tuition and other school fees shall be
                            enjoyed by any undergraduate student who obtains at the end of the semester a GPA of
                            1.50 or better and attains a lowest grade of 2.50, or by any graduate student enrolled in
                            graduate school who obtains at the end of the semester a GPA of 1.25 or better; and <br>
                            c)<b> A college or partial scholarship</b> which consist of a 50 percent reduction in tuition and other
                            school fees shall be enjoyed by any undergraduate student who obtains at the end of the
                            semester a GPA of 1.75 or better and attains a lowest grade of 2.50, or by any graduate
                            student enrolled in the graduate program of the University who obtains at the end of the
                            semester a GPA of 1.5 or better. <br><br>
                            Provided, however, that full or partial scholarships are granted to those not
                            being supported by another agency or institution. <br> <br>
                            A University (or full) and a college (or partial) scholarship shall be valid only for
                            one semester, but shall be renewable for the succeeding semester if the student meets
                            the conditions prescribed. <br>
                            Scholarships in the high school shall be governed by separate rules and
                            regulations promulgated by the University subject to the approval by the Board of
                            Regents. 
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>




        
        <!-- Modal -->
        <div class="modal fade" id="vis" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable  modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">University Vision, Mission and Objectives</h5>
                    </div>
                    <div class="modal-body text-justify">
                        <b>Vision</b> <br>
                        The premier University in historic Cavite recognized for excellence in the development of 
                        globally competitive and morally upright individuals. <br><br>
                        <b>Mission </b><br>
                        Cavite State University shall provide excellent, equitable, and relevant educational opportunities 
                        in the arts, sciences and technology through quality instruction and responsive research and 
                        developmental activities.<br>
                        It shall produce professional, skilled and morally upright individuals for global competitiveness. <br><br>
                        <b>Objectives</b> <br>
                        In addition to, and in support of its mission and policies embodied in the charter, the University 
                        shall: provide a general education program that will promote national identity, cultural consciousness, 
                        moral integrity and spiritual vigor; train that nation’s manpower in the skills required by national 
                        development; develop professions that will provide leadership for the nation; and advance knowledge 
                        through research work and apply new knowledge for improving the quality of human life and 
                        responding effectively to changing societal needs and conditions.

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="ext" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable  modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">RESEARCH AND EXTENSION SERVICES</h5>
                    </div>
                    <div class="modal-body text-justify">
                        In the field of research, the university performs its responsibility in technology and verification. 
                        Linkages and networks are fully maximized. CvSU research projects are funded mostly by the Phillipines 
                        government and other agencies (PCARRD/DOST, DTI, BAR/DA, STARRDEC, and FSRI). <br><br>
                        One of the major functions of the university is community service to entrepreneurs, farmers, 
                        rural women who are now commercially producing banana chips, guyabano concentrates, banana sauce 
                        and other products. <br><br>
                        With external funding support from other agencies, several special have been implemented by 
                        the university since 1986. Among them are: Affiliated Renewable energy Center for Region IV (AREC-IV) 
                        with the Department of Energy (DoE); Sports Development Program with the Philippine Sports 
                        Commission (PSC); Barangay Integrated Development Approach for Nutrition Improvement (BIDANI) of 
                        the Rural Poor with Royal Tropical Institute, The Netherlands, UP Los Baños and the Municipality of 
                        Indang; Institute of Local Government (DILG); Philippines-Australian International Development 
                        Assistance Bureau (AIDAB) and municipal Science Technlogy Advisory Program (MSTAP) with the 
                        Technology and Promotion Institute (TAPI), department of Science and Technology (DOST).
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="foreword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable  modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">FOREWORD</h5></div>
                        <div class="modal-body text-justify">

                    The following set of rules and regulations applies to all bonafide students of Cavite State
                    University System who upon admission, agree and obligate themselves to abide by all existing rules of
                    discipline, to uphold good order of the University, and to contribute in their way to the actualization of
                    the mission of the University. <br><br>
                    In addition to the Students’ Code of Conduct and other pertinent rules contained herein, all
                    other pronouncements circularized, posted in bulletin boards or published in the school, special manuals
                    an SOP’s notices of committees and administrative bodies and councils and memoranda/circulars of
                    duly constituted authorities from part of body of rules and regulations for all students; students are
                    required to take notice of all these rules within the reasonable period of their posting, publication,
                    circulation or dissemination. <br><br>
                    All officer of the Administration, .members of the Administrative and Academic staff, employees
                    and faculty members are considered persons in authority vested with rights and obligation to
                    implement the said rules and regulations.<br><br>
                    Most of the rules contained in this student handbook were taken from the CvSU Manual of
                    Operations 2009 that was approved by the Board of Regents (BOR) on September 3, 2009 per Res. No.
                    85, s. 2009.<br><br>
                    The Student Handbook 2006 as approved by the BOR per Res. No. 84, s. 2006 was updated in
                    order to include relevant information about the University.<br><br>
                    <span class="fw-bold">HUMBLE BEGINNINGS</span><br><br>

                    The University has its humble beginning in 1906 as the Indang Intermediate School with the
                    American “ Thomasites” as the first teachers. Several transformations in the name of the school took
                    place. In 1918 – Indang Farm School, 1927 – Indang Rural High School and then to Don Severino National
                    Agricultural in 1958. The name Don Severino is donated in the Aguinaldo revolutionary government.
                    Don Severino donated a tract of land for use as field laboratory by the School.<br><br>
                    <span class="fw-bold">AS A STATE COLLEGE OF AGRICULTURE</span><br><br>

                    In 1964, the School was converted into a State College by virtue of Republic Act No. 3917 and
                    became known as Don Severino Agricultural College.<br><br>
                    In the beginning of its establishment as a State College, the only program offering was
                    baccalaureate degree in agriculture including the teacher training program in agriculture education.
                    However, due to the demands of parents and in answer to the challenges of Project CALABARZON,
                    major program units such as Arts and Sciences, Education, and Engineering were created in addition to
                    the School of Agriculture in 1992.<br><br>

                    In 1993, in recognition of its achievements and potentials, the College was designated by the
                    Department of Education, Culture and Sports (DECS) as the regional College of Agriculture (RCA), for the
                    Southern Tagalog Region. Being the RCA, DSAC is mandated to assist the Provincial Technical Institutes
                    of Agriculture (PTIA) in the region in the improvement of their curriculum and instructional programs,
                    practical and applied researches, the training of PTIA staff and to lead in the production of instructional
                    materials.<br><br>

                    <span class="fw-bold">AS A STATE UNIVERSITY</span><br><br>

                    On January 22, 1998, by virtue of Republic Act No. 8468, DSAC was converted into CAVITE STATE
                    UNIVERSITY (CvSU). Two years later, the Commission on Higher Education (CHED) designated the
                    University as Center of Development in Agriculture and Agricultural Engineering and in 2009, the
                    Veterinary Medicine.<br><br>
                    In the year 2001, the University had four other campuses. Cavite College of Fisheries (CACOF) in
                    Naic, Cavite and Cavite College of Arts and Trade (CCAT) in Rosario, Cavite were integrated to the
                    University by virtue of CHED Memo No. 27, s.2000. Cavite City Campus was established and started
                    offering courses in the first semester of SY 2001-2002. Finally, Carmona Campus was established
                    through offering of course on the first semester of SY 2002-2003 <br><br>
                    In the first semester, SY 20030-2004, CvSU opened a branch campus in Imus, Cavite. The Trece
                    Martires Campus was established through Memorandum of Agreement (MOA) signed on May 18, 2005
                    to start offering of courses in the first semester SY 2005- 2006. In first semester SY 2006-2007, CvSU
                    opened a branch campus in Silang, Cavite. In addition, the Tanza Campus and the Bacoor Campus were
                    both opened during the first semester of SY 2007-2008 and SY 2008-2009, repectively. <br><br>

                    <span class="fw-bold">A COMMITMENT</span><br><br>

                    Through the years, Cavite State University has remained committed to its mission. Guided by
                    the University’s vision and mission, CvSU shall forever be true to the client it has vowed to serve.
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div>
            </div>
        </div>
        <!-- tilhere --> 

        
        
        


        

        
              




















<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script></body>
</body>
</html>