<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link rel="stylesheet" href="<?php echo base_url('/assets/css/signin.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bg.css')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body style="background-image:url(<?= base_url('/assets/img/')  ?>);">
<section class="h-100 w-100 gradient-form my-3">
  <div class="container pb-5 h-100">
    <div class="row d-flex justify-content-center align-items-center">
      <div class="col-xl-12">
        <div class="text-black">
              <div class="p-md-5 mx-md-4">

                <div class="text-center">
                  <img src="<?php echo base_url('assets/img/cvsu-logo.png')?>"
                  style="width: 185px;" alt="logo">
                  <h4 class="mt-1 mb-2 pb-1 fw-bold">Cavite State University Naic</h4>
                  <h4 class="mb-3 fw-bold ">Student Portal - Admin</h4>
                </div>
                  
                <!-- LOGIN FORM SECTION -->

                <form class="mx-auto col-10 col-md-8 col-lg-6" action="/admin-dashboard" method="post">
                  <p class="">Please log in to your account</p>
                  <p class="text-danger fw-bold"><?php echo $this->session->flashdata('for_encryption')?></p>
                  <p class="text-danger fw-bold"><?php echo $this->session->flashdata('notUser')?></p>
                  <p class="text-danger fw-bold"><?php echo $this->session->flashdata('empty')?></p>
                  <p class="text-success fw-bold"><?php echo $this->session->flashdata('secured')?></p>
                  <p class="text-danger fw-bold"><?php echo $this->session->flashdata('incorrect-pass')?></p>
                  <p class="text-success fw-bold"><?php echo $this->session->flashdata('reset-password')?></p>
                  <p class="text-success fw-bold"><?php echo $this->session->flashdata('newPass')?></p>
                  <p class="text-danger fw-bold"><?php echo $this->session->flashdata('reset-password-error')?></p>

                  <div class="form-outline mb-4">
                    <input type="email" class="form-control" name="email" placeholder="Email Address" />
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" class="form-control mb-3" name="userPassword" placeholder="Password" id="myInput"/>
                    <input type="checkbox" class="mr-2" onclick="myFunction()">
                    <label for="">Show Password</label>
                  </div>

                  <div class="text-center pt-1 mb-4 pb-1">
                    <button class="col-12 btn btn-success fa-lg gradient-custom-2 mb-3" >Log in</button><br>
                  </div>
                </form>

                

                <!-- modal -->
                <div class="modal top fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content text-center">
                            <div class="modal-header h5 text-white bg-success justify-content-center">
                                Password Reset
                            </div>
                            <div class="modal-body px-5">
                                <p class="py-2">
                                    Enter your email address and student number and we'll send you an email with instructions to reset your password.
                                </p>
                                <form action="/reset-password" method="post">
                                    <div class="form-outline">
                                        <input type="email" id="typeEmail" name="reset-email" class="form-control my-3" placeholder="Email Address"/>                                    </div>
                                    <div class="form-outline">
                                        <input type="number" id="" name="studentNumber" class="form-control my-3" placeholder="Student Number"/>
                                    </div>
                                    <input type="submit" value="Reset Password" class="btn btn-success w-100 mb-3"/>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
              <!-- <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                <h4 class="mb-4">Cavite State University Naic - Student Portal</h4>
                <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                  exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </div> -->
            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

    <script>
        function myFunction() {
          var x = document.getElementById("myInput");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
      </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
</html>