<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1 , shrink-to-fit=no">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link rel="stylesheet" href="<?php echo base_url('/assets/css/signin.css')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<!-- <body class="bg-image no-repeat" style="background-image: url('<?php echo base_url('assets/img/cvsu-logo.png')?>');"> -->
    <!-- navigation bar -->
    <!-- JASMINE KRYSTLE CALDAIRA -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/main">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" aria-current="page" href="/student-support">Student Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" aria-current="page" href="/handbook">Student Handbook</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo ucwords($this->session->userdata('shortName'))?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/student-profile">Student Profile</a></li>
                            <li><a class="dropdown-item" href="/enrolled-subjects">Enrolled Courses</a></li>
                            <li><a class="dropdown-item" href="/class-schedule" target="_blank">Class Schedule</a></li>
                            <li><a class="dropdown-item" href="/sems">List of Grades</a></li>
                            <li><a class="dropdown-item" href="/">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="developers" class="py-5 px-4">
        <div class="container">
            <h2 class="text-center text-dark"><?php echo $jasmine['name']?></h2>
            <p class="lead text-center text-dark mt-3 mb-5 text-light fw-bold">STUDENT NUMBER: <?php echo $jasmine['studentNumber']?></p>

            <p class="text-success fw-bold"><?=$this->session->flashdata('secured')?></p>
            
                <div class="card mb-4">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><span class="fw-bold">Address: </span><?php echo $jasmine['address']?></li>
                        <!-- <li class="list-group-item"><span class="fw-bold">Date of Birth: </span><?php echo $ja['dateOfBirth']?></li> -->                      <li class="list-group-item"><span class="fw-bold">Phone Number: </span><?php echo $jasmine['mobilePhone']?></li>
                        <li class="list-group-item"><span class="fw-bold">Email Address: </span><?php echo $jasmine['emailaddress']?></li>
                    </ul>
                </div>
                
            

            <div class="col-md">
                    <div class="card text-dark mb-3">
                        <div class="card-body text-center">
                            <h6 class=" text-dark fw-bold">Course</h6>
                            <p class="card-text text-dark "><?php echo strtoupper($jasmine['course']) ?></p>
                        </div>
                    </div>
                </div> 

            <div class="row g-4">
                <div class="col-md">
                    <div class="card text-dark">
                        <div class="card-body text-center">
                            <h6 class="text-dark fw-bold">Gender</h6>
                            <p class="card-text text-dark "><?php echo $jasmine['gender'] ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md">
                    <div class="card text-dark">
                        <div class="card-body text-center">
                            <h6 class="text-dark fw-bold">Religion</h6>
                            <p class="card-text text-dark "><?php echo $jasmine['religion'] ?></p>
                        </div>
                    </div>
                </div>         
                
                <div class="col-md">
                    <div class="card text-dark">
                        <div class="card-body text-center">
                            <h6 class="text-dark fw-bold">Citizenship</h6>
                            <p class="card-text text-dark "><?php echo $jasmine['citizenship'] ?></p>
                        </div>
                    </div>
                </div>   
                
                <!-- <form action="/update">
                    <input type="submit" value="Update Account Information" class="col-12 btn btn-success fa-lg gradient-custom-2">
                </form> -->
                
                <form action="/password-profile">
                <span class="tt" data-bs-placement="bottom" title="Click here to change your password.">
                    <input type="submit" value="Change Password" class="col-12 btn btn-success fa-lg gradient-custom-2 mb-3">
                </span>
                </form>
            </div>
        </div>

        
    </section>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
        const tooltips = document.querySelectorAll('.tt')
        tooltips.forEach(t => {
            new bootstrap.Tooltip(t)
        })
    </script>
</body>
</html>