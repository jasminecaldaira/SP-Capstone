<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CvSU Naic Student Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/cvsu-logo.png')?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body>
    <!-- navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success px-2 py-3 sticky-top">
        <div class="container">
            <img class="mx-2" src="<?php echo base_url('assets/img/cvsu-logo.png')?>" height='45'>
            <h2 class="navbar-brand text-center text-light">STUDENT PORTAL</h2>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <a class="nav-link mx-2 active" aria-current="page" href="/main">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" aria-current="page" href="/student-support">Student Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" aria-current="page" href="/handbook">Student Handbook</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo ucwords($this->session->userdata('shortName'))?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/student-profile">Student Profile</a></li>
                            <li><a class="dropdown-item" href="/enrolled-subjects">Enrolled Courses</a></li>
                            <li><a class="dropdown-item" href="/class-schedule" target="_blank">Class Schedule</a></li>
                            <li><a class="dropdown-item" href="/sems">List of Grades</a></li>
                            <li><a class="dropdown-item" href="/">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="m-4">
        <div class="container page-body-wrapper col-md-12">
            <div class="card my-3">
                <div class="card-body">
                    <p class="fw-bold">SCHOOL YEAR: <?=$pickyear?></p>
                    <p class="fw-bold">SEMESTER: <?=$picksem?></p>
                    <p class="fw-bold">STUDENT NUMBER: <?=$this->session->userdata['studentNumber']?></p>
                    <p class="fw-bold mb-0">STUDENT NAME: <?=$this->session->userdata('fullName')?></p>
                </div>
            </div>
            <div class="table-responsive">
            <table class="table table-striped">
                <thead class="bg-success text-light">
                    <tr class="text-center">
                        <!-- <th scope="col">SEMESTER</th> -->
                        <th scope="col">SUBJECT CODE</th>
                        <th scope="col">SUBJECT TITLE</th>
                        <th scope="col">GRADES</th>
                        <th scope="col">UNITS</th>
                    </tr>
                </thead>

                <tbody>
                    
<?php   foreach($min as $jas){ ?>
                    <tr scope="row" class="text-center">
                        <!-- <td><?=$jas['semester']?></td> -->
                        <td><?=$jas['subjectcode']?></td>
                        <td><?=$jas['subjectTitle']?></td>
            <?php   if($jas['makeupgrade'] === '-'){   ?>
                        <td><?=$jas['mygrade']?></td>                       
            <?php   }   
                    else if($jas['mygrade'] === '4.00'){   ?>
                        <td>4.00/<?=$jas['makeupgrade']?></td>                       
            <?php   }   
                    else if($jas['mygrade'] === '5.00'){    ?>
                        <td>5.00/<?=$jas['makeupgrade']?></td>                       
            <?php   }
                    else {  ?>
                        <td>INC/<?=$jas['makeupgrade']?></td>
            <?php   }   ?>                                        
                        <td><?=$jas['units']?></td>
                    </tr>
<?php   }   ?>
                </tbody>
            </table>
            </div>
            <p class="fw-bold">Total Units: <?=ABS($credited)?></p> 
            <p class=" fw-bold">GPA: <?=round($grade, 2)?></p>
            <p>Grades will remain unofficial unless verified by the Campus Registrar.</p>
        </div>
    </section>

    <section class="">
        <div class="container">
            
        </div>
    </section>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
        const tooltips = document.querySelectorAll('.tt')
        tooltips.forEach(t => {
            new bootstrap.Tooltip(t)
        })
    </script>
</body>
</html>