<?php

class Subjects extends CI_Controller{

    public function index(){
        $this->load->model('Subject');
        $this->load->model('User');
        $sems['admin'] = $this->User->adminList();
        $sems['sems'] = $this->Subject->showSems();
        $post = $this->input->post();
        $this->Subject->updateSem($post);
        $this->load->view('/admin/user-management', $sems);
    }

    public function viewUserManagement(){
        $this->load->model('User');
        $this->load->model('Subject');

        $admins['admin'] = $this->User->adminList();
        $admins['sems'] = $this->Subject->showSems();
        $this->load->view('/admin/user-management', $admins);
    }

    public function enrolledSubjects(){
        // $this->output->enable_profiler(true);

        $this->load->model('Subject');
        $sems['sems'] = $this->Subject->showSems();
        $post = $this->input->post();
        $yearSem = $this->Subject->fetchYearSem();
        $studentNumber = $this->session->userdata('studentNumber');
        $subjects['subjs'] = $this->Subject->showSubjects($yearSem, $studentNumber);
        $subjects['picksem'] = $yearSem['currentSem'];
        $subjects['pickyear'] = $yearSem['currentYear'];

        if ($this->session->userdata('status') == 'in'){
            $this->load->view('subjects-enrolled/showSubjects', $subjects);
        }
        else{
            redirect('/');
        }
    }
}