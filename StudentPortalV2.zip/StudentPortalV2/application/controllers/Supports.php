<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
/* Include the Composer generated autoload.php file. */
require 'vendor/autoload.php';

class Supports extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->model('User');
    }

    public function index(){
        if ($this->session->userdata('status') == 'in'){
            $this->load->model('Support');
            $emails['emails'] = $this->Support->fetchAllEmail();
            $this->load->view('studentSupport', $emails);        }
        else{
            redirect('/');
        }
        
    }
    public function send(){
        $mail = new PHPMailer(TRUE);
        $email = $this->input->post('emailTo');
        $myemail = $this->input->post('myemail');
        $courseSection = $this->input->post('courseSection');
        $subject = $this->input->post('subject');
        $details = $this->input->post('details');
        $prof = $this->input->post('name');
        $studEmail = $this->session->userdata('email');

        try {
            $mail->setFrom('jasminecaldaira@gmail.com', ucwords($this->session->userdata('shortName')));
            $mail->addAddress($email, $prof);
            $mail->Subject = $subject;
            
            $mail->isHTML(TRUE);
            
            $body = $details;
            $mail->Body = '<html>'.$body.'<br> <br><br>Reply here: </html>' . $myemail;
            $mail->AltBody = $details;
            
            /* SMTP parameters. */
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = TRUE;
            $mail->SMTPSecure = 'tls';
            $mail->Username = 'studentportal@cvsu-naic.edu.ph';
            $mail->Password = 'phdgjruuyznneyps';
            $mail->Port = 587;
            
            /* Disable some SSL checks. */
            $mail->SMTPOptions = array(
            'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
            )
            );
            
            /* Finally send the mail. */
            $mail->send();
            $this->session->set_flashdata('success', 'Message succesfully sent.');
            redirect('/student-support');
        }
        catch (Exception $e)
        {
            echo $e->errorMessage();
        }
        catch (\Exception $e)
        {
            echo $e->getMessage();
        }
    }

    public function addEmail(){
        $this->load->view('add-email');
    }

    public function insertEmail(){

        $this->load->model('Support');
        $post = $this->input->post();
        $result['findings'] = $this->Support->validateAddEmail($post);
		
		if ($result['findings'] == "valid"){
            $this->Support->addEmail($post);
			$this->session->set_flashdata('emailAdded', 'Email Succesfully Added');
			$this->load->view('add-email');
		}
		else {
			$this->session->set_flashdata('addAdminError', $result['findings']);
			$this->load->view('/add-email', $result);
		}
    }

    public function studentHandbook(){
        $this->load->view('student-handbook');
    }
}