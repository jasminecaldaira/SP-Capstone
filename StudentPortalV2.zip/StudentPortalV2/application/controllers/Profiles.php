<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profiles extends CI_Controller {

    public function index(){
        $this->load->model('Profile');
        $userData['jasmine'] = $this->Profile->fetchAll($this->session->userdata('studentNumber'));
        if ($this->session->userdata('status') == 'in'){
            $this->load->view('student-profile', $userData);
        }
        else{
            redirect('/');
        }
    }

}