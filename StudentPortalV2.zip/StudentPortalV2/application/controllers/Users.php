<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
/* Include the Composer generated autoload.php file. */
require 'vendor/autoload.php';

class Users extends CI_Controller {

	public function index()
	{
		session_destroy();
		$this->load->view('login');
	}

	public function handbook(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->view('student-handbook');
        }
        else{
            redirect('/');
        }
	}
	public function home()
	{
		$this->load->model('User');
		$studentNumber = $this->input->post('studentNumber');
		$pass = $this->input->post('userPassword');

		// $this->output->enable_profiler(true);
		if (empty($studentNumber) || empty($pass)){
			$this->session->set_flashdata('empty','All fields required');
			redirect('/');
		}

		$this->session->set_userdata('studentNumber', $studentNumber);
		$this->session->set_userdata('userPassword', $pass);

		$isExisting = $this->User->isExisting($this->session->userdata('studentNumber')); // identify if the user is existing or not via studentNumber
		$userEmail =  $this->User->findEmail($this->session->userdata('studentNumber'));
		$userPhone =  $this->User->findPhone($this->session->userdata('studentNumber'));

		$userData = $this->User->validateUserEmail($studentNumber); // get user status (secured or unsecured) and all user data

		if ($isExisting == "empty"){ // identify if the user is existing or not via studentNumber
			$this->session->set_flashdata('notUser', 'User not found. Please try again.');
			redirect('/');
		}
		else if ($isExisting !== "empty") {
			if ($userData['secretdoor'] == md5($this->session->userdata('userPassword'))){ 
				$this->load->model('Profile');
				$userData = $this->Profile->fetchAll($this->session->userdata('studentNumber'));
				$this->session->set_userdata('fullName', $userData['name']);
				$this->session->set_userdata('shortName', mb_strtolower($userData['shortName']));
				$this->session->set_userdata('status', 'in');
				$this->load->view('home');
			}	

			else if ($userData['secretdoor'] !== md5($this->session->userdata('userPassword')))  {	// if unsecured
				if($userData['secretdoor'] !== $this->session->userdata('userPassword')){
					$this->session->set_flashdata('incorrect-pass','Incorrect password.');
					redirect('/');
				}
				else{
					$this->load->model('User');
					$this->User->securing($this->session->userdata('studentNumber'), $this->session->userdata('userPassword') );
					// redirect('/');
					$this->load->model('Profile');
					$userData = $this->Profile->fetchAll($this->session->userdata('studentNumber'));
					$this->session->set_userdata('fullName', $userData['name']);
					$this->session->set_userdata('shortName', mb_strtolower($userData['shortName']));
					$this->session->set_userdata('status', 'in');
					$this->load->view('home');
				}
				
			}
			else if ($userData['secretdoor'] !== $this->session->userdata('userPassword')){
				$this->session->set_flashdata('incorrect-pass','Incorrect password.');
				redirect('/');
			}
		}
		else { 
			$this->session->set_flashdata('for_encryption','All fields required.');
			redirect('/');
		}
	}

	
	public function main(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->view('home');
        }
        else{
            redirect('/');
        }
	}

	public function schedule(){
		$this->load->helper('url');
		redirect('https://bit.ly/CvSUNaic-ClassSched-2ndSemSY2022-2023');
	}

	public function resetPassword(){
        // var_dump($this->session->userdata());
		$this->load->model('User');

		$userEmail =  $this->User->validateUserEmail($this->input->post('studentNumber'));
	
			$this->session->set_userdata('userEmail', $this->input->post('reset-email'));
			$mail = new PHPMailer(TRUE);
			$email = $this->input->post('reset-email');

			$studEmail = $this->session->userdata('email');

				$mail->setFrom('studentportal@cvsu-naic.edu.ph', 'Cavite State University Naic - Student Portal');
				$mail->addAddress($email, $this->session->userdata('fullName'));
				$mail->Subject = 'Reset Password Link';
				
				$link = 'http://studentportalv2/change-password';
				$mail->isHTML(TRUE);
				
				$mail->Body = '<html>Click the link to reset your password: <br>'.$link.'</html>';
				// $mail->AltBody = ;
				
				/* SMTP parameters. */
				$mail->isSMTP();
				$mail->Host = 'smtp.gmail.com';
				$mail->SMTPAuth = TRUE;
				$mail->SMTPSecure = 'tls';
				$mail->Username = 'studentportal@cvsu-naic.edu.ph';
				$mail->Password = 'phdgjruuyznneyps';
				$mail->Port = 587;
				
				/* Disable some SSL checks. */
				$mail->SMTPOptions = array(
				'ssl' => array(
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true)
				);
				
				/* Finally send the mail. */
				$mail->send();
				$this->session->set_flashdata('reset-password', 'Kindly check your inbox, we have sent you the reset password link.');
				redirect('/');
	}

	public function changePassword(){
		$this->load->view('change-password');
	}

	public function changePass(){

		// $this->output->enable_profiler(true);
		$studentNumber = $this->input->post('studentNumber');
		$newPass = $this->input->post('newPass');

		$this->load->model('User');
		$updated = $this->User->updatePass($studentNumber, $newPass);
		// echo $updated;

		if ($updated == "success") {
			$this->session->set_flashdata('newPass','Your password has been changed. Please login again.');
			redirect('/');
		}
		else{
			echo "oopsxxxxx jasmine, u so numb. there has been an error, contact me (jasmine) please :) lovelots xoxo";
		}
	}

	// ADMINNNNNNNN
	public function admin(){
		session_destroy();
		$this->load->view('login-admin');
	}
	
	public function adminDashboard(){
		// $this->output->enable_profiler(true);
		$this->load->model('User');
		$email = $this->input->post('email');
		$pass = $this->input->post('userPassword');

		if (empty($email) || empty($pass)){
			$this->session->set_flashdata('empty','All fields required');
			redirect('/admin');
		}

		$this->session->set_userdata('email', $email);
		$this->session->set_userdata('userPassword', $pass);

		$isExisting = $this->User->isExistingAdmin($email); 

		$userData = $this->User->validateUserEmailAdmin($email); // get user status (secured or unsecured) and all user data

		if ($isExisting == "empty"){ 
			$this->session->set_flashdata('notUser', 'User not found. Please try again.');
			redirect('/admin');
		}
		else if ($isExisting !== "empty") {
			if ($userData['secretdoor'] == md5($this->session->userdata('userPassword'))){ // if secured
				$this->session->set_userdata('status', 'in');

				if ($this->session->userdata('status') == 'in'){
					$this->load->model('User');
					$admins['admin'] = $this->User->adminList();
					$this->load->view('/admin/admin-dashboard', $admins);
				}
				else{
					redirect('/admin');
				}
			}	
			else if ($userData['secretdoor'] !== md5($this->session->userdata('userPassword')))  {	// if unsecured
				$this->session->set_flashdata('incorrect-pass','Incorrect password.');
				redirect('/admin');
			}
			else if ($userData['secretdoor'] !== $this->session->userdata('userPassword')){
				$this->session->set_flashdata('incorrect-pass','Incorrect password.');
				redirect('/admin');
			}
		}
		else { 
			$this->session->set_flashdata('for_encryption','All fields required.');
			redirect('/admin');
		}
	}

	public function addAdmin(){
        if ($this->session->userdata('status') == 'in'){
			$this->load->view('admin/add-admin');
        }
        else{
            redirect('/admin');
        }
	}
	public function adminHome(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->view('admin/admin-dashboard');
        }
        else{
            redirect('/admin');
        }
	}
	public function createAdmin(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->model('User');
			$post = $this->input->post();
			$email = $this->input->post('email');
			$phoneNumber = $this->input->post('phoneNumber');
			$pass = $this->input->post('pass');
			$result['findings'] = $this->User->validateAddAdmin($post);
	
			if ($result['findings'] == "valid"){
				$this->User->insertAdmin($email, $phoneNumber, $pass);
				$this->session->set_flashdata('addAdminSuccess', 'Admin Succesfully Added');
				redirect('/add-admin');
			}
			else {
				$this->session->set_flashdata('addAdminError', $result['findings']);
				$this->load->view('admin/add-admin', $result);
			}        }
        else{
            redirect('/admin');
        }
	}
	public function userManagement(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->model('User');
			$this->load->model('Subject');

			$admins['admin'] = $this->User->adminList();
			$admins['sems'] = $this->Subject->showSems();
			$this->load->view('/admin/user-management', $admins);
		}
		else{
			redirect('/admin');
		}
	}
	public function updateEmailAdmin(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->view('admin/update-emailAdmin');
        }
        else{
            redirect('/admin');
        }
	}
	public function updateAdminEmail(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->model('User');
			$post = $this->input->post();
			$result['findings'] = $this->User->validateupdateAdminEmail($post);
			$newEmail = $this->input->post('newEmail');
			$oldEmail = $this->input->post('oldEmail');
			$isExisting = $this->User->isExistingAdmin($oldEmail);
			if ($isExisting == "empty"){ 
				$this->session->set_flashdata('notUser', 'User not found. Please try again.');
				redirect('/update-emailAdmin');
			}
			else {
				if ($result['findings'] == "valid"){
					$this->User->updateEmailAdmin($newEmail, $oldEmail);
					$this->session->set_flashdata('adminEmailUpdated', 'Email Address Succesfully Updated');
					redirect('/update-emailAdmin');
				}
				else{
					$this->session->set_flashdata('addAdminError', $result['findings']);
					$this->load->view('admin/update-emailAdmin', $result);
				}
			}        
		}
        else{
            redirect('/admin');
        }
	}
	public function updatePhoneAdmin(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->view('admin/update-phoneAdmin');
        }
        else{
            redirect('/admin');
        }
	}
	public function updateNumber(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->model('User');
			$post = $this->input->post();
			$result['findings'] = $this->User->validateUpdateNumber($post);
			$email = $this->input->post('email');
			$newNumber = $this->input->post('newNumber');
			$oldNumber = $this->input->post('oldNumber');
	
			$isExisting = $this->User->isExistingAdmin($email);
			if ($isExisting == "empty"){ 
				$this->session->set_flashdata('notUser', 'User not found. Please try again.');
				redirect('/update-adminNumber');
			}
			else {
				if ($result['findings'] == "valid"){
					$this->User->updateNumberAdmin($newNumber, $email);
					$this->session->set_flashdata('adminNumberUpdated', 'Phone Number Succesfully Updated');
					redirect('/update-adminNumber');
				}
				else{
					$this->session->set_flashdata('addAdminError', $result['findings']);
					$this->load->view('admin/update-phoneAdmin', $result);
				}
			}        
		}
        else{
            redirect('/admin');
        }	
	}

	public function adminResetPassword(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->view('admin/reset-password');
        }
        else{
            redirect('/admin');
        }
	}

	public function userPasswordResetAdmin(){
		if ($this->session->userdata('status') == 'in'){
			$this->load->model('User');
			$post = $this->input->post();
			$result['findings'] = $this->User->validateUserPasswordResetAdmin($post);
			$studentNumber = $this->input->post('studentNumber');
			$newPass = md5($this->input->post('newPass'));
			
			if ($result['findings'] == "valid"){
				$this->User->resetPassword($studentNumber, $newPass);
				$this->session->set_flashdata('passwordUpdateSuccess', 'Password Succesfully Updated');
				redirect('/admin-reset-password');
			}
			else {
				$this->session->set_flashdata('addAdminError', $result['findings']);
				$this->load->view('admin/reset-password', $result);
			}        
		}
        else{
            redirect('/admin');
        }
		
	}
	public function passwordProfile(){
		$this->load->view('/password-prof');
	}

	public function deactivate(){
		$email = $this->input->post('email');
		$this->load->model('User');
		$this->User->deactivate($email);
		redirect('/user-management');
	}

	public function studData(){
		$this->load->model('User');
		$results['results'] = $this->User->studData();
		$this->load->view('admin/studData', $results);
	}

	public function search(){
		$this->load->model('User');
		$post = $this->input->post();
		$array['products'] = $this->User->search($post);
		$this->load->view('partial/data', $array);
		// var_dump($array['products']);
	}
}



