<?php

class Grades extends CI_Controller {

    public function semesters(){
        if ($this->session->userdata('status') == 'in'){
            $this->load->model('Grade');
            $sem['sem'] = $this->Grade->selectSem($this->session->userdata('studentNumber'));
            $this->load->view('grades/per-sem', $sem);
        }
        else{
            redirect('/');
        }
    }
    public function showGrades(){
        if ($this->session->userdata('status') == 'in'){
            $this->load->model('Grade');
            $post = $this->input->post();
            $studentNumber = $this->session->userdata('studentNumber');
            $grades['picksem'] = $this->input->post('pick-sem');
            $grades['pickyear'] = $this->input->post('pick-year');
            $grades['min'] = $this->Grade->showGradesSem($post);  
           
            $grades['units'] = $this->Grade->unitsFirst($post); 
            $grades['unitss'] = $this->Grade->unitsSec($post); 
            $totalUnits = $grades['units']['units'] - $grades['unitss']['units'];
            $grades['credited'] = $grades['units']['units'] - $grades['unitss']['units']; //

            // GETTING OF UNITS X GRADE
            $first = $this->Grade->getUnitsFirstsem($post);
            $sec = $this->Grade->getUnitsSecsem($post);
            $overallUnits = $first['unitsXgrade'] + $sec['unitsXgrade'];

            if($totalUnits == 0){
                $grades['grade'] = 0;
            }
            else {
                $grades['grade'] = $overallUnits / $totalUnits;
            }
            $this->load->view('grades/showGrades', $grades);   
        }
        else{
            redirect('/');
        }   
    }
    public function allGrades(){
        if ($this->session->userdata('status') == 'in'){
            $this->load->model('Grade');
            $studentNumber = $this->session->userdata('studentNumber');
            $grades['jasmine'] = $this->Grade->getAllGrades($this->session->userdata('studentNumber')); // 1st query
            $grades['units'] = $this->Grade->allUnits(); // 2nd query function
            $grades['unitss'] = $this->Grade->getUnits(); // 3rd query function
            $first = $this->Grade->getUnitsFirst();
            $sec = $this->Grade->getUnitsSec();
                        
            $totalUnits = $grades['units']['units'] - $grades['unitss']['units']; 
            $overallUnits = $first['unitsXgrade'] + $sec['unitsXgrade'];
            $grades['credited'] = $totalUnits;
            $grades['grade'] = $overallUnits / $totalUnits;

            $this->load->view('grades/allGrades', $grades);
        }
        else{
            redirect('/');
        }   
    }
}