<?php

class Subject extends CI_Model{
    
    public function showSem($studentNumber){
        $query = "SELECT semester, schoolyear
        FROM enrollsubjectenrolled
        where studentnumber = ?
        GROUP BY semester, schoolyear
        order by schoolyear DESC";
        $values = array($studentNumber);
        return $this->db->query($query, $values)->result_array();
    }

    public function showSems(){
        $query = "SELECT semester, schoolyear
        FROM enrollsubjectenrolled
        GROUP BY semester, schoolyear
        order by schoolyear DESC , semester DESC";
        return $this->db->query($query)->result_array();
    }

    public function showSubjects($post, $studentNumber){
        $queryy = "SET SQL_BIG_SELECTS=1";
        $this->db->query($queryy);
        $query = "SELECT subj.semester, sched.subjectCode, title.subjectTitle, (sched.units + sched.labunits) AS units 
                  FROM enrollsubjectenrolled as subj 
                  INNER JOIN enrollscheduletbl as sched ON subj.schedcode = sched.schedcode
                  INNER JOIN enrollsubjectstbl as title ON sched.subjectCode = title.subjectcode
                  where subj.studentNumber = ? and subj.semester = ? and subj.schoolyear = ?";
        $values = array($studentNumber, $post['currentSem'], $post['currentYear']);
        return $this->db->query($query, $values)->result_array();
    }

    public function updateSem($post){
        $query = "UPDATE enrollpswdstudtbl SET currentYear = ? , currentSem = ?";
        $values = array($post['pick-year'], $post['pick-sem']);
        $this->db->query($query, $values);
    }

    public function fetchYearSem(){
        $query = "SELECT currentYear, currentSem FROM enrollpswdstudtbl";
        return $this->db->query($query)->row_array();
    }
}