<?php

class Profile extends CI_Model {

    public function fetchAll($studentNumber){
        $queryy = "SET SQL_BIG_SELECTS=1";
        $this->db->query($queryy);
        $userData = $this->db->query("select enrollstudentinformation.studentNumber, enrollstudentinformation.course, enrollstudentinformation.gender, 
        enrollstudentinformation.religion, enrollstudentinformation.citizenship, CONCAT(enrollstudentinformation.firstName,' ', enrollstudentinformation.middleName,' ', enrollstudentinformation.lastName) AS name, 
        CONCAT(enrollstudentinformation.firstName,' ', enrollstudentinformation.lastName) AS shortName, 
		CONCAT(enrollstudentinformation.street,' ', enrollstudentinformation.barangay, ' ', enrollstudentinformation.municipality,' ', enrollstudentinformation.province) as address,  
        enrollstudentinformation.mobilePhone, enrollpswdstudtbl.phonenumber, enrollpswdstudtbl.emailaddress
        from enrollstudentinformation INNER JOIN enrollpswdstudtbl on enrollstudentinformation.studentNumber = enrollpswdstudtbl.studentnumber 
        where enrollstudentinformation.studentnumber =  '$studentNumber'")->row_array();
        return $userData;
    }
}