<?php

class StudInfo extends CI_Model{
    public function fetchAll(){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT * FROM studentinfo WHERE studentnumber = ?";
        $value = $studentNumber;
        return $this->db->query($query, $value)->result_array();

    }
}