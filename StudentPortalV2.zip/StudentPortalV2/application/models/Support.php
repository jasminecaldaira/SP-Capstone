<?php

class Support extends CI_Model{
    public function fetchAllEmail(){
        $emails = $this->db->query("SELECT * from profemails")->result_array();
        return $emails;
    }
    public function validateAddEmail($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email Address', 'trim|required');
        $this->form_validation->set_rules('fullName', 'Full Name', 'trim|required');

        if ($this->form_validation->run()){
            return "valid";
        }
        else{
            return array(validation_errors());
        }
    }

    public function addEmail($post){
        $query = "INSERT INTO profemails (emailAddress, fullName) VALUES (?, ?)";
        $values = array($post['email'], $post['fullName']);
        $this->db->query($query, $values);
    }
}