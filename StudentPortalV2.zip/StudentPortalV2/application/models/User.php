<?php

class User extends CI_Model {

    public function validateUserEmail($studentNumber) {
        $query = "SELECT secretdoor, emailaddress, phonenumber, status FROM enrollpswdstudtbl WHERE studentnumber = '$studentNumber'";
        $userData = $this->db->query($query)->row_array();
        return $userData;
    }
    public function validateUserEmailAdmin($email) {
        $query = "SELECT secretdoor, emailaddress, phonenumber, status FROM enrollpswdstudtbl WHERE emailaddress = '$email'";
        $userData = $this->db->query($query)->row_array();
        return $userData;
    }
    public function encryptUserData($userData, $studentNumber){
        $email = $userData['emailaddress'];
        $pass = md5($userData['secretdoor']);
        $phonenumber = $userData['phonenumber'];

        $query = "UPDATE enrollpswdstudtbl
                  SET secretdoor = '$pass', emailaddress = '$email', phonenumber = '$phonenumber', status = 'secured' 
                  WHERE studentnumber = '$studentNumber'";
        $this->db->query($query);
    }

    public function findEmail($studentNumber){
        $query = "SELECT emailaddress FROM enrollpswdstudtbl WHERE studentnumber = '$studentNumber'";
        $userEmail = $this->db->query($query)->row_array();
        $empty = "empty";

        if (empty($userEmail['emailaddress'])){
            return $empty;
        }
    }
    public function findPhone($studentNumber){
        $query = "SELECT phonenumber FROM enrollpswdstudtbl WHERE studentnumber = '$studentNumber'";
        $userPhone = $this->db->query($query)->row_array();
        $empty = "empty";

        if (empty($userPhone['phonenumber'])){
            return $empty;
        }
    }
    public function isExisting($studentNumber){
        $query = "SELECT studentnumber FROM enrollpswdstudtbl WHERE studentnumber = $studentNumber";
        $isExisting = $this->db->query($query)->row_array();
        $empty = "empty";

        if (empty($isExisting['studentnumber'])){
            return $empty;
        }
    }
    public function isExistingAdmin($email){
        $query = "SELECT emailaddress FROM enrollpswdstudtbl WHERE emailaddress = '$email'";
        $isExistingAdmin = $this->db->query($query)->row_array();
        $empty = "empty";

        if (empty($isExistingAdmin['emailaddress'])){
            return $empty;
        }
    }

    public function updateAcc($post){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "UPDATE enrollpswdstudtbl SET emailaddress = ?, phonenumber = ? WHERE studentnumber = ?";
        $value = array($post['emailAddress'], $post['phoneNumber'], $studentNumber);
        $this->db->query($query, $value);

        $queryy = "INSERT INTO studentinfo (studentNumber, firstName, lastName, middleName, street, barangay, municipality, province, 
                    gender, religion, citizenship, mobilephone, course, emailAddress) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $values = array(strtoupper($post['studno']), strtoupper($post['fname']), strtoupper($post['lname']), strtoupper($post['mname']), 
                  strtoupper($post['street']), 
                  strtoupper($post['brgy']), strtoupper($post['municipality']), strtoupper($post['province']), 
                  strtoupper($post['gender']), strtoupper($post['religion']), strtoupper($post['citizenship']), strtoupper($post['phoneNumber']), 
                  strtoupper($post['course']), strtoupper($post['emailAddress']));
        $this->db->query($queryy, $values);
        // return tue;
    }

    public function updatePass($studentNumber, $newPass){
        $newPassword = md5($newPass);
        $query =  "UPDATE enrollpswdstudtbl SET secretdoor = ? WHERE studentnumber = ?";
        $values = array($newPassword, $studentNumber);
        $this->db->query($query, $values);
        $success = "success";
        return $success;
    }
    
    public function insertAdmin($email, $phoneNumber, $pass){
        $query = "INSERT INTO enrollpswdstudtbl (studentnumber, secretdoor, emailaddress, phonenumber, registerdate, role, status)
                  VALUES (?,?,?,?,?,?,?)";
        $values = array('', md5($pass), $email, $phoneNumber, date('Y-m-d, H:i:s'), 'admin', 'secured');

        $this->db->query($query, $values);
    }

    public function updateEmailAdmin($newEmail, $oldEmail){
        $query = "UPDATE enrollpswdstudtbl SET emailaddress = ? WHERE emailaddress = ? AND role = 'admin'";
        $values = array($newEmail, $oldEmail);

        $this->db->query($query, $values);
    }

    public function updateNumberAdmin($newNumber, $email){
        $query = "UPDATE enrollpswdstudtbl SET phonenumber = ? WHERE  emailaddress = ? AND role = 'admin'";
        $values = array($newNumber, $email);

        $this->db->query($query, $values);
    }

    public function resetPassword($studentNumber, $newPass){
        $query = "UPDATE enrollpswdstudtbl SET secretdoor = ? WHERE studentnumber  = ?";
        $values = array($newPass, $studentNumber);

        $this->db->query($query, $values);
    }

    public function validate($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('studno', 'Student Number', 'trim|required');
        $this->form_validation->set_rules('fname', 'First Name', 'trim|required');
        $this->form_validation->set_rules('lname', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('mname', 'Middle Name', 'trim|required');
        $this->form_validation->set_rules('phoneNumber', 'Phone Number', 'trim|required');
        $this->form_validation->set_rules('emailAddress', 'Email Address', 'trim|required');
        $this->form_validation->set_rules('street', 'Street', 'trim|required');
        $this->form_validation->set_rules('brgy', 'Barangay', 'trim|required');
        $this->form_validation->set_rules('province', 'Municipality', 'trim|required');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required');
        $this->form_validation->set_rules('religion', 'Religion', 'trim|required');
        $this->form_validation->set_rules('citizenship', 'Citizenship', 'trim|required');

        if ($this->form_validation->run()){
            return "valid";
        }
        else{
            return array(validation_errors());
        }
    }

    public function validateAddAdmin($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('phoneNumber', 'Phone Number', 'trim|required');
        $this->form_validation->set_rules('email', 'Email Address', 'trim|required');
        $this->form_validation->set_rules('pass', 'Password', 'trim|required');

        if ($this->form_validation->run()){
            return "valid";
        }
        else{
            return array(validation_errors());
        }
    }

    public function validateUserPasswordResetAdmin($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('studentNumber', 'Student Number', 'trim|required');
        $this->form_validation->set_rules('newPass', 'New Password', 'trim|required');

        if ($this->form_validation->run()){
            return "valid";
        }
        else{
            return array(validation_errors());
        }
    }

    public function validateupdateAdminEmail($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('oldEmail', 'Student Number', 'trim|required');
        $this->form_validation->set_rules('newEmail', 'New Password', 'trim|required');

        if ($this->form_validation->run()){
            return "valid";
        }
        else{
            return array(validation_errors());
        }
    }

    public function validateUpdateNumber($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email Address', 'trim|required');
        $this->form_validation->set_rules('oldNumber', 'Old Number', 'trim|required');
        $this->form_validation->set_rules('newNumber', 'New Number', 'trim|required');


        if ($this->form_validation->run()){
            return "valid";
        }
        else{
            return array(validation_errors());
        }
    }

    public function updatemyacc($post){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "UPDATE enrollpswdstudtbl SET emailaddress = ?, phonenumber = ? WHERE studentnumber = ?";
        $value = array($post['emailAddress'], $post['phoneNumber'], $studentNumber);
        $this->db->query($query, $value);

        $queryy = "UPDATE studentinfo SET studentnumber = ? , firstName = ? , lastName = ?, middleName=?, street=?, barangay=?, municipality=?, province=?,
                    gender=?, religion=?, citizenship=?, mobilephone=?, course=?, emailAddress=?";
        $values = array(strtoupper($post['studno']), strtoupper($post['fname']), strtoupper($post['lname']), strtoupper($post['mname']), 
                  strtoupper($post['street']), 
                  strtoupper($post['brgy']), strtoupper($post['municipality']), strtoupper($post['province']), 
                  strtoupper($post['gender']), strtoupper($post['religion']), strtoupper($post['citizenship']), strtoupper($post['phoneNumber']), 
                  strtoupper($post['course']), strtoupper($post['emailAddress']));
        $this->db->query($queryy, $values);
        // return tue;
    }

    public function adminList(){
        return $this->db->query("SELECT * FROM enrollpswdstudtbl WHERE role = 'admin'")->result_array();
    }

    public function deactivate($email){
        $query = 'UPDATE enrollpswdstudtbl SET role = NULL WHERE emailaddress = ?';
        $value = array($email);
        $this->db->query($query, $value);
    }

    public function securing($studentNumber, $pass){
        $this->db->query("UPDATE enrollpswdstudtbl SET status = 'secured', secretdoor = md5('$pass') WHERE studentNumber = $studentNumber");
    }

    public function studData(){
        $query = "SELECT enrollstudentinformation.studentNumber, enrollpswdstudtbl.emailaddress AS emailaddress, 
        enrollstudentinformation.firstName, enrollstudentinformation.lastName, enrollstudentinformation.middleName,
        enrollstudentinformation.dateOfBirth, enrollstudentinformation.gender, 
        enrollstudentinformation.mobilePhone AS mobilePhone, enrollstudentinformation.course
        FROM enrollstudentinformation INNER JOIN enrollpswdstudtbl ON enrollstudentinformation.studentNumber = enrollpswdstudtbl.studentnumber 
        WHERE enrollstudentinformation.studentNumber != 201210000";
        return $this->db->query($query)->result_array();
    }

    public function search($post){

        // if (!empty($post['name'])){
        //     if ($post['orderBy'] == 'lth'){
                // $query = "SELECT * FROM enrollstudentinformation WHERE lastName LIKE ?";
                $query = "SELECT enrollstudentinformation.studentNumber, enrollpswdstudtbl.emailaddress AS emailaddress, 
                            enrollstudentinformation.firstName, enrollstudentinformation.lastName, enrollstudentinformation.middleName,
                            enrollstudentinformation.dateOfBirth, enrollstudentinformation.gender, 
                            enrollstudentinformation.mobilePhone AS mobilePhone, enrollstudentinformation.course
                            FROM enrollstudentinformation LEFT JOIN enrollpswdstudtbl 
                            ON enrollstudentinformation.studentNumber = enrollpswdstudtbl.studentnumber 
                            WHERE enrollstudentinformation.lastName = ?
                            AND enrollstudentinformation.gender = ? AND enrollstudentinformation.course = ?";
                $value = array($post['name'], $post['gender'], $post['course']);
                return $this->db->query($query, $value)->result_array();
            // }
            // else{
            //     $query = "SELECT * FROM products WHERE name LIKE ? ORDER BY price DESC";
            //     $value = array($post['name'].'%');
            //     return $this->db->query($query, $value)->result_array();
            // }
        }

        // if ($post['orderBy'] == 'lth'){
        //     $query = "SELECT * FROM products WHERE price BETWEEN ? AND ? ORDER BY price ASC";
        //     $values = array($post['min'], $post['max']);
        //     return $this->db->query($query, $values)->result_array();
        // }
        // else{
        //     $query = "SELECT * FROM products WHERE price BETWEEN ? AND ? ORDER BY price DESC";
        //     $values = array($post['min'], $post['max']);
        //     return $this->db->query($query, $values)->result_array();
        // }
    // }
}