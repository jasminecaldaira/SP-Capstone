<?php

class Grade extends CI_Model {

    public function selectSem($studentNumber){
        $query = "SELECT semester, schoolyear
                    FROM enrollgradestbl
                    where studentnumber = $studentNumber
                    GROUP BY semester, schoolyear
                    order by schoolyear desc";
        return $this->db->query($query)->result_array();
    }

    public function showGradesSem($post){
        $studentNumber = $this->session->userdata('studentNumber');
        $queryy = "SET SQL_BIG_SELECTS=1";
        $this->db->query($queryy);
        $query = "SELECT enrollgradestbl.studentnumber, concat (enrollgradestbl.schoolyear, ' - ', enrollgradestbl.semester) as semyear, 
        enrollgradestbl.semester, enrollgradestbl.subjectcode, enrollsubjectstbl.subjectTitle, enrollgradestbl.mygrade, enrollgradestbl.makeupgrade,
        enrollgradestbl.units from enrollgradestbl, enrollsubjectstbl where enrollgradestbl.subjectcode = enrollsubjectstbl.subjectcode and 
        studentnumber = ? and enrollgradestbl.semester = ? and enrollgradestbl.schoolyear = ?";
        $values = array($studentNumber, $post['pick-sem'], $post['pick-year']);
        return $this->db->query($query, $values)->result_array();
    }
// PER SEM GETTING OF UNITS
    public function unitsFirst($post){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT ABS(SUM(units)) AS units FROM enrollgradestbl WHERE studentnumber = ? AND schoolyear = ? 
                    AND semester= ? AND mygrade != 'S'";
        $values = array($studentNumber, $post['pick-year'], $post['pick-sem']);

        $units = $this->db->query($query, $values) -> row_array();
        return $units;
    }
    public function unitsSec($post){
        $studentNumber = $this->session->userdata('studentNumber');

        $query = "SELECT ABS(SUM(units)) AS units FROM enrollgradestbl WHERE studentnumber = ? AND schoolyear = ? 
                    AND semester = ? AND mygrade  IN ('4.00', '5.00', 'INC') and makeupgrade = '-';";
        $values = array($studentNumber, $post['pick-year'], $post['pick-sem']);

        $units = $this->db->query($query, $values) -> row_array();
        return $units;
    }

// PRODUCT OF UNITS X GRADES
    public function getUnitsFirstsem($post){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT sum(mygrade*units) AS unitsXgrade FROM enrollgradestbl WHERE studentnumber = ? AND semester = ?
                    and schoolyear = ? and mygrade NOT IN ('4.00', 'INC', '5.00', 'S') and makeupgrade = '-';";
        $values = array($studentNumber, $post['pick-sem'], $post['pick-year']);
        return $this->db->query($query, $values)->row_array();
    }

    public function getUnitsSecsem($post){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT sum(makeupgrade*units) AS unitsXgrade FROM enrollgradestbl WHERE studentnumber = ?  AND semester = ?
                    and schoolyear = ?";
        $values = array($studentNumber, $post['pick-sem'], $post['pick-year']);
        return $this->db->query($query, $values)->row_array();
    }

    public function getUnitsFirst(){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT sum(mygrade*units) AS unitsXgrade FROM enrollgradestbl
                    WHERE studentnumber = ? and mygrade NOT IN ('4.00', 'INC', '5.00', 'S') and makeupgrade = '-'";
        $values = array($studentNumber);
        return $this->db->query($query, $values)->row_array();
    }

    public function getUnitsSec(){
        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT sum(makeupgrade*units) AS unitsXgrade FROM enrollgradestbl WHERE studentnumber = ?";
        $values = array($studentNumber);
        return $this->db->query($query, $values)->row_array();
    }
    public function getProductUnitsSem($studentNumber, $post){
        $query1 = "SELECT * FROM enrollgradestbl WHERE studentnumber = ? AND schoolyear = ?  and semester = ? and mygrade = 'INC'";
        $values1 = array($studentNumber, $post['pick-year'], $post['pick-sem']);
        $inc = $this->db->query($query1, $values1)->result_array();

        // $this->db->query("update enrollgradestbl set mygrade = makeupgrade WHERE makeupgrade != '-'");        
        $query = "SELECT sum(mygrade*units) AS unitsXgrade FROM enrollgradestbl
            WHERE studentnumber = ? AND schoolyear = ? and semester = ? AND mygrade NOT IN ('S', '4.00', '5.00', 'INC');";
        $values = array($studentNumber, $post['pick-year'], $post['pick-sem']);
        $unitsXgrades = $this->db->query($query, $values)->result_array();
        return $unitsXgrades;
    }

    public function getAllGrades($studno){
        $queryy = "SET SQL_BIG_SELECTS=1";
        $this->db->query($queryy);
        $query = "SELECT enrollgradestbl.studentnumber, concat (enrollgradestbl.schoolyear, ' - ', enrollgradestbl.semester) as semyear, 
        enrollgradestbl.semester, enrollgradestbl.subjectcode, enrollsubjectstbl.subjectTitle, enrollgradestbl.mygrade, enrollgradestbl.makeupgrade,
        enrollgradestbl.units from enrollgradestbl, enrollsubjectstbl where enrollgradestbl.subjectcode = enrollsubjectstbl.subjectcode and 
        studentnumber = ?";
        $value = array($studno);
        return $this->db->query($query, $value)->result_array();
    }

    public function allUnits(){
        // $studentNumber = $this->session->userdata('studentNumber');
        // $query = "SELECT ABS(SUM(units)) AS units FROM enrollgradestbl WHERE studentnumber = ? AND mygrade NOT IN ('S', '4.00', '5.00', 'INC') ";
        // $values = array($studentNumber);

        // $units = $this->db->query($query, $values) -> row_array();
        // return $units;

        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT ABS(SUM(units)) AS units FROM enrollgradestbl WHERE studentnumber = ? AND mygrade != 'S'";
        $values = array($studentNumber);

        $units = $this->db->query($query, $values) -> row_array();
        return $units;
    }

    
    public function getUnits(){
        // $studentNumber = $this->session->userdata('studentNumber');
        // $query = "SELECT ABS(SUM(units)) AS units FROM enrollgradestbl WHERE studentnumber = ? AND mygrade NOT IN ('S', '4.00', '5.00', 'INC') ";
        // $values = array($studentNumber);

        // $units = $this->db->query($query, $values) -> row_array();
        // return $units;

        $studentNumber = $this->session->userdata('studentNumber');
        $query = "SELECT ABS(SUM(units)) AS units FROM enrollgradestbl WHERE studentnumber = ? 
                    AND mygrade IN ('4.00', '5.00', 'INC') AND makeupgrade = '-';";
        $values = array($studentNumber);

        $units = $this->db->query($query, $values) -> row_array();
        return $units;
    }
    
    public function getProductUnitsXSem($studentNumber){
        $query1 = "SELECT * FROM enrollgradestbl WHERE studentnumber = ? and mygrade NOT IN ('S', '4.00', '5.00', 'INC');";
        $values1 = array($studentNumber);
        $inc = $this->db->query($query1, $values1)->result_array();

        // $this->db->query("update enrollgradestbl set mygrade = makeupgrade WHERE makeupgrade != '-'");        

        $query = "SELECT sum(mygrade*units) AS unitsXgrade FROM enrollgradestbl
            WHERE studentnumber = ? AND mygrade NOT IN ('S', '4.00', '5.00', 'INC')";
        $values = array($studentNumber);
        $unitsXgrades = $this->db->query($query, $values)->result_array();
        return $unitsXgrades;
        
    }

    public function backInc(){
        $this->db->query('UPDATE enrollgradestbl SET mygrade = "INC" WHERE makeupgrade != "-"');
    }
}